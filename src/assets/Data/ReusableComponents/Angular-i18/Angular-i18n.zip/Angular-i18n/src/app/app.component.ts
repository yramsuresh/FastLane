import { Component, OnInit, Inject, PLATFORM_ID, Optional } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-i18';
  langs = ['en', 'fr'];
  language: String = 'English';

constructor(private translateService: TranslateService) {translateService.setDefaultLang('en');}

public switchLanguage(lang: string): void {
  //this.translateService.setDefaultLang(lang);
  this.translateService.use(lang);
    if (lang == 'en') {
      this.language = "English";
    } else if (lang == 'fr') {
      this.language = "French";
    }
  
}

}