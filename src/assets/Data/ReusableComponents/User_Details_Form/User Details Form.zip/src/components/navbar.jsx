import React, { Component } from 'react';

class NavBar extends Component {
    render() { 
        return (
          <div>

                <h3 className="text-center  p-3 mb-2 bg-info text-white font-italic">User Details Form</h3>
          </div>
        );
    }
}
 
export default NavBar;