import React from 'react';
import { Spinners } from './components/Spinners';
import './App.css';

function App() {
  return (
    <div className='App'>
      <h1 style={{ textAlign: 'center', marginBottom: '40px' }}>
        Reusable React Loading Spinners
      </h1>
      <Spinners />
    </div>
  );
}

export default App;
