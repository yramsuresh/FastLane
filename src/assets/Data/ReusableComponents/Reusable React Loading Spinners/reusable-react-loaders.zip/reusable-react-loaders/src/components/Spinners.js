import React from 'react';
import {
  Default,
  DualRing,
  Ellipsis,
  Ring,
  Roller,
  Spinner,
} from '../components';

export const Spinners = () => {
  return (
    <div className='normal-spinners'>
      <Default color='#000000' size={80} />
      <DualRing color='#000000' size={80} />
      <Ellipsis color='#000000' size={80} />
      <Ring color='#000000' size={80} />
      <Roller color='#000000' size={80} />
      <Spinner color='#000000' size={80} />
    </div>
  );
};
