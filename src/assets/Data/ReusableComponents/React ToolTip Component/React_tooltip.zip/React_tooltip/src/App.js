import React, {Component} from 'react';
import CustomTooltip from './components/CustomTooltip'
import './App.scss';

class App extends Component {
  state={
    toolbarPosition: 'bottom',
  }
  changePositionHandler=(e)=> {
    this.setState({
      toolbarPosition: e.target.value
    })
  }
  render(){
    return (
      <div className="container">
        <br/>
        <br/>
        <br/>
        <br/>
        <div className="tooltip-wrapper">
          Lorem ipsum dolor sit amet consectetur adipisicing elit. 
          Exercitationem quidem ipsam nihil autem soluta debitis 
          itaque suscipit incidunt reiciendis veniam eum possimus aperiam voluptatum dicta, molestiae consectetur.
          <CustomTooltip background='rgba(0, 0, 0, 0.5)' color="#fff" tipPosition={this.state.toolbarPosition}>
            Hi I am tool tip 
          </CustomTooltip>
        </div>
        <br/>
        <br/>
        <br/>
        <div className="custom-control custom-radio">
            <input type="radio" id="top" name="customRadio" value="top" checked={this.state.toolbarPosition==='top'}
             onChange={this.changePositionHandler} className="custom-control-input"/>
            <label className="custom-control-label" htmlFor="top">Top</label>
        </div>
        <div className="custom-control custom-radio">
            <input type="radio" id="right" name="customRadio" value="right" checked={this.state.toolbarPosition==='right'}
            onChange={this.changePositionHandler} className="custom-control-input"/>
            <label className="custom-control-label" htmlFor="right">Right</label>
        </div>
        <div className="custom-control custom-radio">
            <input type="radio" id="bottom" name="customRadio" value="bottom" checked={this.state.toolbarPosition==='bottom'}
            onChange={this.changePositionHandler}  className="custom-control-input"/>
            <label className="custom-control-label" htmlFor="bottom">Bottom</label>
        </div>
        <div className="custom-control custom-radio">
            <input type="radio" id="left" name="customRadio" value="left" checked={this.state.toolbarPosition==='left'}
            onChange={this.changePositionHandler} className="custom-control-input"/>
            <label className="custom-control-label" htmlFor="left">Left</label>
        </div>
      </div>
    );
  }
}

export default App;
