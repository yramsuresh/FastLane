import React from 'react'
import clsx from 'clsx'

const Tooltip = props=> {
    return(
        <div className={clsx('custom-tooltip', props.tipPosition)} style={{backgroundColor: props.background, color: props.color}}>
            {props.children}
        </div>
    )
}

export default Tooltip