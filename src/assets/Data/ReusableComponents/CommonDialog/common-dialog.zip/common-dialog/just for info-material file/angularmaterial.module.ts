import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { 
  MatInputModule,
  MatStepperModule,
  MatProgressBarModule,
  MatFormFieldModule,
  MatRadioModule,
  MatDatepickerModule,
  MatNativeDateModule,
  MatSelectModule,
  MatSlideToggleModule,
  MatChipsModule,
  MatIconModule,
  MatDialogModule,
  MatButtonModule,
  MatTabsModule,
  MatToolbarModule,
  MatMenuModule,
  MatAutocompleteModule,
  MatSnackBarModule,
  MatIconRegistry,
  MatTooltipModule,
  MatTableModule,
  MatPaginatorModule
} 
from '@angular/material';
import { OnlynumberDirective } from './directive/onlynumber.direrective';
import { DragDropDirective } from './directive/drag-drop.directive';
import { DomSanitizer } from '@angular/platform-browser';
import { NameFieldDirective} from './directive/name-field.directive';
import { CommonAddAppointmentComponent } from '../_sharedcomponents/common-add-appointment/common-add-appointment.component';
import { CommonDisplayAppointmentComponent } from '../_sharedcomponents/common-display-appointment/common-display-appointment.component';
import { TranslateModule, TranslateLoader } from '@ngx-translate/core';
import { environment } from 'src/environments/environment';
import { TranslateHttpLoader } from '@ngx-translate/http-loader';
import { HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

export function HttpLoaderFactory(http: HttpClient) {
  let deployURL = environment.deployURL;

  //return new TranslateHttpLoader(http, `${deployURL}/assets/assets1/i18n/`, '.json');
  return new TranslateHttpLoader(http, `/src/assets//i18n/`, '.json');
}

@NgModule({
  declarations: [
    DragDropDirective,
    OnlynumberDirective,
    NameFieldDirective,
    CommonAddAppointmentComponent,
    CommonDisplayAppointmentComponent
  ],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    MatInputModule,
    MatStepperModule,
    MatProgressBarModule,
    MatFormFieldModule,
    MatRadioModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    MatTabsModule,
    MatToolbarModule,
    MatMenuModule,
    MatAutocompleteModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatTableModule,
    MatPaginatorModule,
    TranslateModule.forChild({
      loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
      }
    })
  ],
  exports: [
    DragDropDirective,
    OnlynumberDirective,
    CommonAddAppointmentComponent,
    CommonDisplayAppointmentComponent,
    MatInputModule,
    MatStepperModule,
    MatProgressBarModule,
    MatFormFieldModule,
    MatRadioModule,
    MatSelectModule,
    MatSlideToggleModule,
    MatChipsModule,
    MatIconModule,
    MatDialogModule,
    MatButtonModule,
    MatDatepickerModule,
    MatTabsModule,
    MatToolbarModule,
    MatMenuModule,
    MatAutocompleteModule,
    MatSnackBarModule,
    MatTooltipModule,
    NameFieldDirective,
    MatInputModule,
    MatTableModule,
    MatToolbarModule,
    MatPaginatorModule
  ],
  providers: [
    MatDatepickerModule
  ]
})
export class AngularmaterialModule {
  icons = ['plus', 'bell', 'calender', 'eye', 'news', 'profile', 'up-arrow', 'down-arrow', 'done', 'download', 'filter', 'create', 'delete', 'editicon', 'sort', 'nounp', 'noun', 'noun_tracker', 'Icon ionic-ios-add-circle'];
  constructor(
    public domSanitizer: DomSanitizer,
    public matIconRegistry: MatIconRegistry
  ) {
    this.registerCustomIcon();
    this.registerPortalIconSet();
  }
  registerCustomIcon() {
    this.icons.map(icon => {
      this.matIconRegistry.addSvgIcon(
        `custom-${icon}`,
        this.domSanitizer.bypassSecurityTrustResourceUrl(`./assets/icons/${icon}.svg`)
      );
    })
  }
  registerPortalIconSet() {
    //
    this.matIconRegistry.addSvgIconSetInNamespace(
      'portal',
      this.domSanitizer.bypassSecurityTrustResourceUrl(`./assets/icons/portal-icons.svg`)
    );
    this.matIconRegistry.addSvgIconSetInNamespace(
      'globaldashboard',
      this.domSanitizer.bypassSecurityTrustResourceUrl(`./assets/icons/globaldashboard/global-dashboard-icons.svg`)
    );
  }
}
