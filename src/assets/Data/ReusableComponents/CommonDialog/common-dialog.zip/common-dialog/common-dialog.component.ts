import { Component, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
// import * as jspdf from 'jspdf';    
// import html2canvas from 'html2canvas';
import { MatSnackBar } from '@angular/material';

export interface CommonDialogData {
  isSuccess: boolean,
  title: string,
  message: string,
  anotherMessage?: string,
  showButton?: string,
  patient: any,
  testData: [],
  addAnotherTestReport: boolean,
  cancelOption?: string
}

@Component({
  selector: 'app-common-dialog',
  templateUrl: './common-dialog.component.html',
  styleUrls: ['./common-dialog.component.scss']
})
export class CommonDialogComponent {

  constructor(
    public dialogRef: MatDialogRef<CommonDialogComponent>,
    private snackBar: MatSnackBar,
    @Inject(MAT_DIALOG_DATA) public data: CommonDialogData
  ) { }

  onNoClick():void {
    this.dialogRef.close();
  }

  closeDialog(e, shouldAddAnotherReport):void {
    e.preventDefault();
    this.dialogRef.close(shouldAddAnotherReport);
  }

}
