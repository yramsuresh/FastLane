import React, {useState, useEffect, useReducer} from 'react';
import './styles/index.css';
import TableHeader from './contents/TableHeader';
import TableBody from './contents/TableBody';
import PageLimit  from './features/PageLimit';
import SearchFilter from './features/SearchFilter';
import Pagination from './features/Pagination';
import { sortingData, getHeaderList } from './actions';
import {TableReducer} from './reducers/TableReducer';

export const TableContext = React.createContext(null);

const DataTable  = (props) =>{
    const [state, dispatch] = useReducer(TableReducer, props.data);
    const [pageLimit, setPageLimit] = useState(props.pageSize);
    const [currentPage, setCurrentPage] = useState(1);
    const [tableData, setTableData] = useState(state);

    //Dynamic Header
    const headersList = getHeaderList(props.data);

    // callback function for sorting and pagination
    const sortTableData = (params) =>{
        const sortedData = sortingData(state, params.sortBy, params.sortType);
        setTableData([...sortedData]); 
    }
    const onChangePage = (e, page) =>{
        e.preventDefault();
        setCurrentPage(page);
    }
    const onChangePageLimit =(event) =>{
        setPageLimit(parseInt(event.target.value));
        setCurrentPage(1);
    }

    useEffect(()=>{
        setCurrentPage(1);
    },[state])

    return(
        <React.Fragment>
            <TableContext.Provider value={[state, dispatch]}>
                <div className="table-top-align">
                    <PageLimit onChangePageLimit={onChangePageLimit} pageLimitRange={props.pageSize}/>
                    <SearchFilter data={props.data}/>
                </div>
                <table className="table table-bordered table-hover">
                    <TableHeader headers={headersList} sortTableData={sortTableData}/>
                    <TableBody headers={headersList} 
                                rows={state.slice(currentPage*pageLimit - pageLimit,pageLimit*currentPage)}
                    />
                </table>
                {state.length >= Math.max(state.length, pageLimit) && 
                    <Pagination 
                        dataLength={Math.ceil(state.length/pageLimit)} 
                        currentPage={currentPage} 
                        onChangePage={onChangePage}
                    />
                }
            </TableContext.Provider>
         </React.Fragment>
    ) 
}

export default DataTable;