import React from 'react';
import DataTable from './global/components/DataTable/DataTable'; 
import data from  './data/db.json'
import './App.css';

function App() {
  return (
    <div className="">
        <DataTable data ={data} pageSize="5"/> 
    </div>
  );
}

export default App;
