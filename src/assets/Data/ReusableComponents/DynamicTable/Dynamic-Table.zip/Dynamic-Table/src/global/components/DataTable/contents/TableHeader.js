import React from 'react';

const TableHeader  = (props) =>{
    const {headers, sortTableData} = props;
    return(
        <thead className="thead-dark">
            <tr>
            { headers && headers.map((value, index) =>{
                return (
                <th key={index}>
                    {value.charAt(0).toUpperCase() +value.slice(1)} 
                    <div className="btn-group"> 
                        <button onClick={(e)=>sortTableData({sortType: 'ascending', sortBy: value })}>&#x25B2;</button>
                        <button onClick={(e)=>sortTableData({sortType: 'descending', sortBy: value})}> &#x25BC;</button>
                    </div>
                </th> )
            })}
            </tr>
        </thead>
    )
}
export default React.memo(TableHeader);