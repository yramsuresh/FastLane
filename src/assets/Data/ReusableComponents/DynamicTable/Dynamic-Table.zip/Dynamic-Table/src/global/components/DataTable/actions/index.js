
function includesStr(values, str) {
  return values.map(function (value) {
    return String(value).toLowerCase();
  }).find(function (value) {
    return value.includes(str);
  });
}

// Searching Filter
export const filterData = (value, data, dispatch) =>{
  let filteredData;
  const lowercasedValue = value.toLowerCase().trim();
  if (lowercasedValue === "") {
    filteredData =  data;
  } 
  else {
    filteredData = data.filter(function (item) {
      return includesStr(Object.values(item), lowercasedValue);
    });
  }
  dispatch ({type:"SEARCH", payload: filteredData})
}

// Dynamic Header list for Table 
export const getHeaderList = (data) => {
  if(Array.isArray(data)){
    return Object.keys(data.reduce(function(result, obj) {
      return Object.assign(result, obj);
    }, {}))
  }else{
    return Object.keys(data);
  }
};

// Sorting functionality of each column in Table
export const sortingData = (data, sortBy, sortType) =>{
  return data.sort((a, b) => {
      if(a[sortBy] < b[sortBy] && sortType === 'ascending') {
          return -1;
      }
      if (a[sortBy] > b[sortBy] && sortType === 'descending') {
          return -1;
      }
      return 0;
  });
}
