import React  from 'react';

const BuildRow = (props) => {
    const {row, headers} = props;
    return headers.map((value, index) => {
        return <td data-title={value} key={index}>{row[value]}</td>
    })
};

const TableBody  = (props) =>{
    const {headers, rows} = props;
    return(
        <tbody>
            { rows.length > 0 ? rows.map((value, index) => {
                return(
                    <tr key={index}>
                        <BuildRow row={value} headers={headers} />
                    </tr>
                ) 
            }) : <tr><th class="no-data"colspan={headers.length}>No Records Found !!!</th></tr>}
        </tbody>
    )
}
export default TableBody;