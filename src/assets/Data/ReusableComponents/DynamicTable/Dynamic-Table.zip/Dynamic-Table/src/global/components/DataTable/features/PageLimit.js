import React from 'react';

const PageLimit = (props) =>{
    let pageRange = props.pageLimitRange;
    return(
        <div className="page-limit">
            <label htmlFor="page-menu">Page size: </label>
            <select id="page-menu" onChange={(event) =>props.onChangePageLimit(event)}>
                <option value={pageRange}>{pageRange}</option>
                <option value={pageRange*2}>{pageRange*2}</option>
                <option value={pageRange*4}>{pageRange*4}</option>
                <option value={pageRange*6}>{pageRange*6}</option>
                <option value={pageRange*10}>{pageRange*10}</option>
            </select>
        </div>
    )
}

export default PageLimit;