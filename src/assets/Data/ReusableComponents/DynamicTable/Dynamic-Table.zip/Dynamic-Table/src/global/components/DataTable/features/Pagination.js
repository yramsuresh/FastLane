import React from 'react';

const renderPageNumbers = (pageNumbers, currentPage, onChangePage) =>{ 
    let liElem = [];
    for (let i = 1; i <= pageNumbers; i++) {
        if(currentPage === i-1){
            
        }
        liElem.push(  
            <li key={i} className={`page-item${ currentPage === i ? ' active' : ''}`} >
                <a className="page-link" href="#" onClick={(e)=>onChangePage(e, i)}>{i} </a> 
            </li>
        );
    }
    return liElem;
}

const Pagination =(props) =>{
    const {dataLength, currentPage, onChangePage, pageLimit} = props;
    return(
        <nav aria-label="Table Pagination">
            <ul className="pagination">
                { currentPage !== 1 &&
                <li className="page-item">
                    <a className="page-link" href="#" aria-label="Previous" onClick={(e)=>onChangePage(e, currentPage-1)}>
                    <span aria-hidden="true">&laquo;</span>
                    <span className="sr-only">Previous</span>
                    </a>
                </li> }
            {renderPageNumbers(dataLength, currentPage, onChangePage)}
            {currentPage !== dataLength &&
            <li className="page-item">
                    <a className="page-link" href="#" aria-label="Next" onClick={(e)=>onChangePage(e, currentPage+1)}>
                    <span aria-hidden="true">&raquo;</span>
                    <span className="sr-only">Next</span>
                    </a>
                </li>
            }
            </ul>
        </nav>
    )
}

export default Pagination;