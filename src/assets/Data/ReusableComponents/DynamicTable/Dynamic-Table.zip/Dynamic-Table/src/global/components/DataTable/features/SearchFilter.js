import React, {useContext} from 'react';
import {filterData} from '../actions';
import {TableContext} from '../DataTable'; 

function onSearchData(e, data, dispatch) {
    const value = e.target.value;
    filterData(value, data, dispatch);
}

const SearchFilter =(props) =>{
    const [, dispatch]= useContext(TableContext);
    return(
        <div className="input-group">
            <label htmlFor="searchData">
                Search: 
            </label>
             <input type="text" name="search" id="searchData" class="form-control" onChange={(e) =>onSearchData(e, props.data, dispatch)} />
        </div>
    )
}

export default SearchFilter;
