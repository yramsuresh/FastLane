export const environment = {
  production: true,
  applicationServerPublicKey: `BBOLXi9QUfWOK4o-Q6n6uDwRdFzo6DJGuzEydZ9ZNibjrRmEQ3mjKndHcykBuZE7k-ORiTvR9u8aRC972lWlrvg`
};
