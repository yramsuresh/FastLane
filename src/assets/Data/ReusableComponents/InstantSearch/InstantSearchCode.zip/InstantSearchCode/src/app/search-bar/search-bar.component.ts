import { Component, OnInit, ViewChild, ElementRef,EventEmitter,Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { DataService } from '../data.service';
import { Post } from '../data';

@Component({
  selector: 'app-search-bar',
  templateUrl: './search-bar.component.html',
  styleUrls: ['./search-bar.component.css']
})
export class SearchBarComponent implements OnInit {

  myControl = new FormControl();
  filteredOptions: Observable<string[]>;
  allPosts: Post[];
  autoCompleteList: any[]

  @ViewChild('autocompleteInput',{static: false}) autocompleteInput: ElementRef;
  @Output() onSelectedOption = new EventEmitter();

  constructor(
    private dataService: DataService
  ) { }

  ngOnInit() {
    //console.log('Inside ngonInit() in search bar');
    this.dataService.getPosts().subscribe(posts => {
      this.allPosts = posts

    });

    this.myControl.valueChanges.subscribe(userInput => {
     // console.log('Inside valueChanges() in search bar myControl');
      this.autoCompleteTitleList(userInput);
    })
  }

  private autoCompleteTitleList(input) {
    //console.log('Inside autoCompleteTitleList() in search bar');
    let categoryList = this.filterCategoryList(input)
    this.autoCompleteList = categoryList;
  }

  filterCategoryList(val) {
    //console.log('Inside filterCategoryList() in search bar');
    var categoryList = []
    if (typeof val != "string") {
      return [];
    }
    if (val === '' || val === null) {
      return [];
    }
    return val ? this.allPosts.filter(s => s.title.toLowerCase().indexOf(val.toLowerCase()) != -1)
      : this.allPosts;
  }

  displayFn(post: Post) {
    //console.log('Inside displayFn() in search bar');
    let k = post ? post.title : post;
    return k;
  }

  filterPostList(event) {
    //console.log('Inside filterPostList() in search bar');
    var posts= event.source.value;
        if(!posts) {
          this.dataService.searchOption=[]
        }
        else {          

            this.dataService.searchOption.push(posts);
            console.log(posts.count);
            this.onSelectedOption.emit(this.dataService.searchOption)
        }
        
        this.focusOnPlaceInput();

       
        
  }


  removeOption(option) {
    //console.log('Inside removeOption() in search bar');
        
    let index = this.dataService.searchOption.indexOf(option);
    if (index >= 0)
        this.dataService.searchOption.splice(index, 1);
        this.focusOnPlaceInput();

        this.onSelectedOption.emit(this.dataService.searchOption)
}

focusOnPlaceInput() {
  //console.log('Inside focusOnPlaceInput() in search bar');
  this.autocompleteInput.nativeElement.focus();
  this.autocompleteInput.nativeElement.value = '';
}


}
