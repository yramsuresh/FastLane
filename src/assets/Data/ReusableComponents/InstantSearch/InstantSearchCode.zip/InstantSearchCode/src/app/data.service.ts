import { Injectable } from '@angular/core';
import { Post } from './data';
import { Observable } from 'rxjs';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { environment } from '../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  searchOption=[]
  public postsData: Post[]
  postUrl : string = environment.apiURL; 

  constructor(private http: HttpClient) { }

  getPosts(): Observable<Post[]>{
    //console.log('Inside getPosts() in DataService');
    return this.http.get<Post[]>(this.postUrl);
    
  }

  filterListOptions() {
    //console.log('Inside filterListOptions() in DataService');
    let posts = this.postsData;
        let filteredPostsList = [];
        for (let post of posts) {
            for (let options of this.searchOption) {
                if (options.title === post.title) {
                  filteredPostsList.push(post);
                }
            }
        }
        //console.log(filteredPostsList);
        return filteredPostsList;
  }
}
