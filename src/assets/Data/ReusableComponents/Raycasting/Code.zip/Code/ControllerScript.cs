/**

The purpose of this class is used to implement ray casting functionality
Author : LTI
Date modified : 25th July 2019

**/

using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ControllerScript : MonoBehaviour
{

	private static RaycastHit hit = null; 	
    private static GameObject gameObject = null;
	private static ControllerScript instance = null;
     
     // Game Instance Singleton
     public static ControllerScript Instance
     {
         get
         { 
             return instance; 
         }
     }
     
     private void Awake()
     {
         // if the singleton hasn't been initialized yet
         if (instance != null && instance != this) 
         {
             Destroy(this.gameObject);
         }
 
         instance = this;
         DontDestroyOnLoad( this.gameObject );
     }

	/**
	This method is used to create the ray cast on the game object 
	**/
	public static void createRaycast(RaycastHit hit,Vector3 origin, Vector3 direction ){
		
        if (Physics.Raycast(origin, direction, out hit))
        {

            if (hit.collider != null)
            {

                if (gameObject != hit.collider.gameObject)
                {
                    gameObject.SendMessage("Ray cast hit");
                    //your custom logic goes here
									
                }

            }
        }
        else
        {
            if (gameObject != null)
            {

                gameObject = null;
            }

        }
	}
	   
}
