export class Resume {
  profilePic: string;
  name: string;
  address: string;
  contactNo: number;
  email: string;
  emailSubject: string;
  documentContent: string;
  emailCC: string;
  emailBCC: string;
  socialProfile: string;
  signature: string;
  signatureKeyword: string;
  textFieldKeyword: string;
  otherDetails: string;
  constructor() {}
}
