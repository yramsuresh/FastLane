// import { async, ComponentFixture, TestBed } from '@angular/core/testing';

// import { MultilevelTreeTableComponent } from './multilevel-tree-table.component';

// describe('MultilevelTreeTableComponent', () => {
//   let component: MultilevelTreeTableComponent<T, F>;
//   let fixture: ComponentFixture<MultilevelTreeTableComponent<T, F>>;

//   beforeEach(async(() => {
//     TestBed.configureTestingModule({
//       declarations: [ MultilevelTreeTableComponent ]
//     })
//     .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(MultilevelTreeTableComponent);
//     component = fixture.componentInstance;
//     fixture.detectChanges();
//   });

//   it('should create', () => {
//     expect(component).toBeTruthy();
//   });
// });
