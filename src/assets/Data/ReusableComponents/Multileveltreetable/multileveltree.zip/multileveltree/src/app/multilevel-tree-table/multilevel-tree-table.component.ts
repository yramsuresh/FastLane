import { Component, OnInit, AfterViewInit, ViewChildren, QueryList, Renderer2, Input, Output, EventEmitter, SimpleChanges } from '@angular/core';
import { FlatTreeControl } from '@angular/cdk/tree';
import { MatTreeFlatDataSource, MatTreeFlattener, MatTreeNode } from '@angular/material/tree';
import { BehaviorSubject } from 'rxjs';
import { SelectionModel } from '@angular/cdk/collections';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { Observable, Subscription } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';
import { MatIconRegistry } from '@angular/material/icon';

/**
 * Tree Configuration for @Input() treeData
 * 
 * childKey is the key of treeData object passed as string which
 * holds the children of tree node
 * 
 * uniqueKey is used to generate unique ID which is required by
 * QA team to perform automation testing
 * It is good to set the uniqueKey as the key of treeData which
 * is unique for each entry throughout the data
 * If uniqueKey is not provided, the element is assigned id=" "
 * multilevel-tree-table no longer accepts uniqueKey as a property
 * in treeTableConfig and will be removed in the next release
 * 
 * rowSelections must define selectionType as either 'single' or
 * 'multple'
 * bIsParentNodeSelectable
 * true        --> make parent node selectable
 *                 when some child nodes are selected, parent node
 *                 becomes indeterminate
 * false       --> does not allow parent node to be selected
 * unspecified --> does not allow parent node to be selected
 * 
 * bIsNodeClickable
 * true        --> allows row selection (row is highlighted)
 * false       --> does not allow row selection
 * 
 * bIsTreeCollapsed
 * allNodesExpanded        --> all the nodes are expanded by default
 * allNodesCollapse       --> all the nodes are collapse by default
 * firstNodeExpanded --> first node is expanded by default
 * firstLevelExpanded         --> root nodes are expanded by default
 *
 * @export
 * @interface ITreeTableConfig
 */
export interface ITreeTableConfig {
  childKey: string; // <- VERY IMPORTANT!
  uniqueKey?: string;
  bIsTreeCollapsed?: 'allNodesExpanded' | 'allNodesCollapse' | 'firstNodeExpanded' | 'firstLevelExpanded';
  rowSelections?: {
    selectionType?: 'single' | 'multiple';
    bIsParentNodeSelectable?: boolean;
    bIsNodeClickable?: boolean;
  }
  columnConfig: IColumnConfig[];
}

/**
 * Column Configuration for @Input() treeData
 * 
 * Property                 | Description                             |
 * -------------------------+---------------------------------------- |
 * ----- Header ----------------------------------------------------- |
 * header: {}, <----------- | Would not render header at all          |
 * header: {                |                                         |
 *   bIsFixed: true, <----- | true would render header and footer     |
 *                          | sticky and only content would be        |
 *                          | scrollable                              | 
 *   contents: [ <----------| contents can be multiple in a single    |
 *                          | table header cell                       |
 *     {                    |                                         |
 *       type: '', <------- | Type of content in header cell          |
 *                          | text                                    |
 *       label: '', <------ | Content to be displayed in header cell  |
 *     }                    |                                         |
 *   ]                      |                                         |
 * },                       |                                         |
 *                          |                                         |
 * ----- Content ---------------------------------------------------- |
 * content: {               |                                         |
 *   type: '', <----------- | Type of content of tree-table           |
 *                          | text| checkbox                          |
 *   property: '' <-------- | Property of treeData object which would |
 *                          | be rendered in single cell              |
 * },                       |                                         |
 *                          |                                         |
 * ----- Footer ----------------------------------------------------- |
 * footer: {}, <----------- | Would not render footer at all          |
 * footer: {                |                                         |
 *   bIsFixed: true, <----- | true would render header and footer     |
 *                          | sticky and only content would be        |
 *                          | scrollable                              |
 *   contents: [ <----------| contents can be multiple in a single    |
 *                          | table footer cell                       |
 *     {                    |                                         |
 *       type: '', <------- | Type of content in footer cell          |
 *                          | text | button                           |
 *       label: '' <------- | Content to be displayed in footer cell  |
 *     }                    |                                         |
 *   ]                      |                                         |
 * },                       |                                         |
 *                          |                                         |
 * ----- Additional Configurations ---------------------------------- |
 * bIsTreeContent: true, <- | This indicates which column would have  |
 *                          | tree structure in the table             |
 *                          | Only one column in the entire config    |
 *                          | must have this property set as true     |
 *                          |                                         |
 * style: { <-------------- | style itself is optional, when provided,|
 *                          | must have width specified               |
 *   width: '', <---------- | width if set to auto, resets to 120px   |
 *                          | by CSS                                  |
 *   property: value <----- | Other CSS styles are optional           |
 * }                        |                                         |
 * -------------------------+---------------------------------------- |
 *
 * @interface IColumnConfig
 */
interface IColumnConfig {
  header: {
    bIsFixed?: boolean;
    contents?: {
      type: 'text';
      label: string;
      options?: {
        bIsDisabled?: boolean;
        [key: string]: string | boolean;
      };
    }[];
  };
  content: {
    type: 'text' | 'checkbox';
    property: string; // <- VERY IMPORTANT
    options?: { [key: string]: string; }
  };
  footer: {
    bIsFixed?: boolean;
    contents?: {
      type: 'text' | 'button';
      label: string;
      index?: number;
      options?: {
        bIsDisabled?: boolean;
        [key: string]: string | boolean;
      };
    }[]
  };
  bIsTreeContent?: boolean;
  style?: {
    width: string;
    [key: string]: string;
  };
}

/**
 * Simplified Column Configuration to be used by DOM
 *
 * @interface ISimplifiedColumnConfig
 */
interface ISimplifiedColumnConfig {
  header: {
    bIsFixed?: boolean;
    contents?: {
      type: string;
      label?: string;
      options?: { bIsDisabled?: boolean;[key: string]: string | boolean; };
    }[];
  };
  content: {
    type: string;
    property: string;
    options?: { [key: string]: string; };
  };
  footer: {
    bIsFixed?: boolean;
    contents?: {
      type: string;
      label: string;
      index?: number;
      options?: { bIsDisabled?: boolean;[key: string]: string | boolean; };
    }[];
  };
  bIsTreeContent?: boolean; // <- VERY IMPORTANT
  cellClasses?: string[];
  cellStyles?: { [key: string]: string; };
}

/**
 * Simplified Tree Configuration to be used by DOM
 *
 * @interface ISimplifiedConfig
 */
interface ISimplifiedConfig {
  header: { bExists: boolean; bIsFixed?: boolean; };
  footer: { bExists: boolean; bIsFixed?: boolean; };
  content: {
    bIsSelectable: boolean;
    selectionType?: 'single' | 'multiple';
    bIsParentNodeSelectable?: boolean;
    bIsNodeClickable: boolean;
  };
  bIsTreeCollapsed: 'allNodesExpanded' | 'allNodesCollapse' | 'firstNodeExpanded' | 'firstLevelExpanded';
  uniqueKey: string;
  columnConfig: ISimplifiedColumnConfig[];
}

/**
 * To acquire the references of tree nodes in order to
 * manipulate the connecting lines
 *
 * @interface ITreeNodeStructure
 */
interface ITreeNodeStructure {
  nodeEl: HTMLElement;
  lineHolder?: {
    containerEl: HTMLDivElement;
    verticalLineEl?: HTMLDivElement;
    horizontalLines?: HTMLDivElement[];
  };
  treeTableCell?: {
    treeTableCellEl: HTMLDivElement;
    expand?: {
      buttonHolderEl: HTMLDivElement;
      buttonEl?: HTMLButtonElement
    };
  }
};

/**
 * To handle minor adjustments in placement of an line element/s
 *
 * @interface IAdjust
 */
interface IAdjust {
  top: number;
  left: number;
  bottom: number;
  right: number;
  width: number;
  height: number;
};

/**
 * Multilevel Tree Table class with generic types
 *
 * @export
 * @class MultilevelTreeTableComponent
 * @implements {OnInit}
 * @implements {AfterViewInit}
 * @template T
 * @template F
 */
@Component({
  selector: 'app-multilevel-tree-table',
  templateUrl: './multilevel-tree-table.component.html',
  styleUrls: ['./multilevel-tree-table.component.scss']
})
export class MultilevelTreeTableComponent<T, F> implements OnInit, AfterViewInit {

  @Input() treeTableConfig: ITreeTableConfig;
  // @Input() treeData: T[];
  @Input()
  set treeData(treeNodes: T[]) {
    this.dataChange$.next(treeNodes);
  }
  get treeData(): T[] {
    return this.dataChange$.getValue();
  };
  dataChange$: BehaviorSubject<T[]> = new BehaviorSubject<T[]>([]);
  @Input() viewMode: any;

  @Output() propertyChange = new EventEmitter();
  @Output() tableAction = new EventEmitter();

  @Input() expandTreeTrigger?: boolean = false; //complement this property to expand the tree


  treeDataCopy: T[];

  selectedTabSubscription: Subscription;
  simplifiedConfig: ISimplifiedConfig;
  dataSource: MatTreeFlatDataSource<T, F>;
  treeControl: FlatTreeControl<F>;
  treeFlattener: MatTreeFlattener<T, F>;
  treeNodes$: BehaviorSubject<{ treeNodes: MatTreeNode<F>[], toggledNode: F }> = new BehaviorSubject<{ treeNodes: MatTreeNode<F>[], toggledNode: F }>({ treeNodes: [], toggledNode: null });
  bShowColumn: boolean;
  multiLevelTreeTableNodes$: Observable<any>

  @ViewChildren(MatTreeNode) treeNodesQL: QueryList<MatTreeNode<F>>;
  treeNodesEl: MatTreeNode<F>[];
  toggledNode: F = null;

  checklistSelection: SelectionModel<F>;

  /**
   * Creates an instance of MultilevelTreeTableComponent.
   * @param {Renderer2} renderer
   * @memberof MultilevelTreeTableComponent
   */
  constructor(
    private renderer: Renderer2,
    public iconRegistry: MatIconRegistry,
    sanitizer: DomSanitizer
  ) { 
    iconRegistry.addSvgIcon(
      'plus',
      sanitizer.bypassSecurityTrustResourceUrl('assets/icons/add_circle.svg')
    ),
      iconRegistry.addSvgIcon(
        'minus',
        sanitizer.bypassSecurityTrustResourceUrl('assets/icons/remove_circle.svg')
      );
  }

  /**
   * Component when initialized would perform following tasks
   * 1. Generate tree data
   * 2. Generate simplified configuration 
   *
   * @memberof MultilevelTreeTableComponent
   */
  ngOnInit(): void {

    this.dataChange$.subscribe((updatedData: T[]) => {
      this.generateTreeData(updatedData);
      this.treeDataCopy = this.treeData.slice();
    });

    // this.generateTreeData(this.treeData);
    this.simplifyConfig(this.treeTableConfig);
    if (this.simplifiedConfig.content.bIsSelectable) this.initializeSelection();

    // fromEvent(window, 'resize').pipe(debounceTime(50)).subscribe(() => { this.connectLines(); }); // <- experimental feature

    // this.treeDataCopy = [...this.treeData]; // <- comment this if tslib warning is thrown
    this.treeDataCopy = this.treeData.slice(); // <- use this instead
  }

  ngOnChanges(changes: SimpleChanges): void {
    if (changes) {
      if (changes.expandTreeTrigger && (!!changes.expandTreeTrigger.currentValue == !changes.expandTreeTrigger.previousValue)) this.treeControl.expandAll()
    }
  }

  /**
   * Handle QueryList changes subscriptions
   * Expand all the nodes of a tree
   *
   * @memberof MultilevelTreeTableComponent
   */
  ngAfterViewInit(): void {
    if (this.treeTableConfig.bIsTreeCollapsed === 'allNodesExpanded') {
      this.treeControl.expandAll();
    } else if (this.treeTableConfig.bIsTreeCollapsed === 'firstNodeExpanded') {
      this.treeControl.collapseAll();
      this.treeControl.expand(this.treeControl.dataNodes[0]);
    } else if (this.treeTableConfig.bIsTreeCollapsed === 'allNodesCollapse') {
      this.treeControl.collapseAll();
    } else if (this.treeTableConfig.bIsTreeCollapsed === 'firstLevelExpanded') {
      this.treeControl.dataNodes.forEach((singleNode: F) => {
        if (singleNode['level'] == 0) this.treeControl.expand(singleNode)
      })
    }
    // Detect changes in tree nodes native elements
    // when a tree node is expanded / collapsed
    console.log(this.treeControl);
    // this.treeControl.dataNodes.forEach((singleNode: F) => { singleNode. = false; })
    this.treeNodesQL.changes.subscribe((qList: QueryList<MatTreeNode<F>>) => {
      this.treeNodes$.next({ treeNodes: qList.toArray(), toggledNode: this.toggledNode });
    });
    // Render connecting lines with updated 
    // tree node elements
    this.treeNodes$.subscribe((updatedData: { treeNodes: MatTreeNode<F>[], toggledNode: F }) => {
      this.treeNodesEl = updatedData.treeNodes;
      (!!updatedData.toggledNode) ? this.connectLines(updatedData.toggledNode) : this.connectLines();
    });
  }

  initializeSelection(): void {
    // if (!!this.treeTableConfig.rowSelections) this.checklistSelection = new SelectionModel<F>((this.treeTableConfig.rowSelections.selectionType === 'multiple') ? true : false);
    this.checklistSelection = new SelectionModel<F>((this.treeTableConfig.rowSelections.selectionType === 'multiple') ? true : false);
    this.checklistSelection.clear();
    this.treeControl.dataNodes.forEach((singleNode: F) => {
      !!singleNode['uiSelected'] ? this.checklistSelection.select(singleNode) : this.checklistSelection.deselect(singleNode);
    })
  }

  _transformer = (node: T, level: number) => {
    let flatNode: F = {} as F;
    Object.keys(node).forEach((key: string) => { flatNode[key] = node[key] });
    flatNode['level'] = level;
    flatNode['expandable'] = !!node[this.treeTableConfig.childKey] ? !!node[this.treeTableConfig.childKey].length : false;
    return flatNode;
  };
  nGetLevel = (flatNode: F): number => !!flatNode['level'] ? flatNode['level'] : 0;
  bIsExpandable = (flatNode: F): boolean => !!flatNode['expandable'] ? flatNode['expandable'] : false;
  getChildren = (node: T): T[] => !!node[this.treeTableConfig.childKey].length ? node[this.treeTableConfig.childKey] : [];
  bHasChild = (index: number, flatNode: F): boolean => { flatNode['index'] = !!index ? index : 0; return !!flatNode['expandable'] ? flatNode['expandable'] : false };

  /**
 * Generate datasource for MatTree
 *
 * @param {T[]} treeData
 * @memberof MultilevelTreeTableComponent
 */
  generateTreeData(treeData: T[]) {
    this.treeFlattener = new MatTreeFlattener(
      this._transformer,
      this.nGetLevel,
      this.bIsExpandable,
      this.getChildren
    );
    this.treeControl = new FlatTreeControl<F>(
      this.nGetLevel,
      this.bIsExpandable
    );
    this.dataSource = new MatTreeFlatDataSource(
      this.treeControl,
      this.treeFlattener
    );
    this.dataSource.data = treeData;
  }

  /**
   * Generate simplified configuration 
   * This simplified configuration is used in template 
   * to display data
   *
   * @param {ITreeTableConfig} treeConfig
   * @memberof MultilevelTreeTableComponent
   */
  simplifyConfig(treeConfig: ITreeTableConfig) {
    this.simplifiedConfig = {
      header: { bExists: treeConfig.columnConfig.every((singleColumn: IColumnConfig) => (JSON.stringify(singleColumn.header) !== '{}')) },
      footer: { bExists: treeConfig.columnConfig.every((singleColumn: IColumnConfig) => (JSON.stringify(singleColumn.footer) !== '{}')) },
      content: { bIsSelectable: !!treeConfig.rowSelections, bIsNodeClickable: !!treeConfig.rowSelections },
      bIsTreeCollapsed: 'allNodesCollapse',
      uniqueKey: '',
      columnConfig: []
    };

    // Check if unique key exists
    // this is required to generate element id dynamically
    // required for QA
    this.simplifiedConfig.uniqueKey = !!treeConfig.uniqueKey ? treeConfig.uniqueKey : '';

    // Check if the tree must be collapsed on getting rendered
    this.simplifiedConfig.bIsTreeCollapsed = (treeConfig.bIsTreeCollapsed)

    // Check if either header or footer is fixed
    this.simplifiedConfig.header.bIsFixed = (this.simplifiedConfig.header.bExists) ? treeConfig.columnConfig.some((singleColumn: IColumnConfig) => !!singleColumn.header.bIsFixed) : false;
    this.simplifiedConfig.footer.bIsFixed = (this.simplifiedConfig.footer.bExists) ? treeConfig.columnConfig.some((singleColumn: IColumnConfig) => !!singleColumn.footer.bIsFixed) : false;

    // Check the nature of selections of rows, if rows are selectable
    if (!!treeConfig.rowSelections) {
      // this.simplifiedConfig.content.selectionType = !!(treeConfig.rowSelections.selectionType) : treeConfig.rowSelections.selectionType;
      if (!!treeConfig.rowSelections.selectionType) {
        this.simplifiedConfig.content.selectionType = treeConfig.rowSelections.selectionType
        this.simplifiedConfig.content.bIsNodeClickable = false;
      } else {
        this.simplifiedConfig.content.bIsNodeClickable = !!treeConfig.rowSelections.bIsNodeClickable;

      }
      this.simplifiedConfig.content.bIsParentNodeSelectable = (this.simplifiedConfig.content.selectionType === 'multiple') ? ((!!treeConfig.rowSelections.bIsParentNodeSelectable) ? treeConfig.rowSelections.bIsParentNodeSelectable : false) : false;
    } else { }
    // this.simplifiedConfig.content.selectionType = !!treeConfig.rowSelections ? treeConfig.rowSelections.selectionType : 'single';

    treeConfig.columnConfig.forEach((singleColumn: IColumnConfig, index: number) => {

      // Initialize simplified config for column under iteration
      this.simplifiedConfig.columnConfig[index] = {
        header: singleColumn.header,
        content: singleColumn.content,
        footer: singleColumn.footer,
        cellClasses: [],
        cellStyles: {},
      };

      // Check if the column is the tree content holder
      this.simplifiedConfig.columnConfig[index].bIsTreeContent = (!!singleColumn.bIsTreeContent) ? singleColumn.bIsTreeContent : false;

      // Classes for cell border and differentiating 
      // between tree and non-tree cells
      this.simplifiedConfig.columnConfig[index].cellClasses.push(!!singleColumn.bIsTreeContent ? 'tree-node-cell' : 'non-tree-node-cell');
      this.simplifiedConfig.columnConfig[index].cellClasses.push(!!index ? ((index === treeConfig.columnConfig.length - 1) ? 'last-table-cell-border' : 'table-cell-border') : 'first-table-cell-border');

      // Inline styles for cells
      if (!!(singleColumn.style)) { // <- remove risky widths
        if (singleColumn.style['width'] === 'auto') delete singleColumn.style['width'];
        if (!!singleColumn.style['flex']) delete singleColumn.style['flex'];
        if (!!singleColumn.style['flex-basis']) delete singleColumn.style['flexBasis'];
      }
      this.simplifiedConfig.columnConfig[index].cellStyles = (!!singleColumn.style) ? singleColumn.style : {};
      this.simplifiedConfig.columnConfig[index].cellStyles['min-width'] = (!!singleColumn.bIsTreeContent) ? '300px' : ((!!singleColumn.style) ? singleColumn.style.width : '120px');

    });

    //console.table([treeConfig, this.simplifiedConfig]);
    // console.log(this.simplifiedConfig);
  }

  /**
   * Update the treeNodes when a node is expanded/collapsed
   * Click node is also passed as subscriber next value
   *
   * @param {F} clickedNode
   * @memberof MultilevelTreeTableComponent
   */
  toggleNodeExpansion(clickedNode: F, property: any) {
    this.toggledNode = clickedNode;
    this.treeNodes$.next({ treeNodes: this.treeNodesQL.toArray(), toggledNode: clickedNode });
  }

  /**
   * Maps node of type ToDoFlatNode to MatTreeNode<ToDoFlatNode>
   * This method is used to provide ElementRef of ToDoFlatNode
   * This function is called everytime a node is interacted with
   * Calling this function repeteadly is neccessary since 
   * the nodes of tree keep changing every time a node is toggled
   *
   * @param {F[]} inputNodes
   * @param {F} [toggledNode]
   * @returns {MatTreeNode<F>[]}
   * @memberof MultilevelTreeTableComponent
   */
  mapToTreeNode(inputNodes: F[], toggledNode?: F): MatTreeNode<F>[] {
    let mappedTreeNodes: MatTreeNode<F>[] = [];

    // filter only nodes specific to the one toggled
    if (!!toggledNode) {
      mappedTreeNodes = this.treeNodesEl
        .filter((singleNode: MatTreeNode<F>) => inputNodes.includes(singleNode.data))
        .reverse()
        .filter((singleNode: MatTreeNode<F>) => singleNode.level !== toggledNode['level']);
    } else {

      // filter all nodes
      let filteredNodes: F[] = this.treeControl.dataNodes
        .filter((singleControl: F) => inputNodes.includes(singleControl));
      if (!!filteredNodes.length) {
        mappedTreeNodes = this.treeNodesEl
          .filter((singleNode: MatTreeNode<F>) => filteredNodes.includes(singleNode.data))
          .sort((currentNode: MatTreeNode<F>, nextNode: MatTreeNode<F>) => this.treeControl.dataNodes.findIndex((singleControl: F) => singleControl === currentNode.data) - this.treeControl.dataNodes.findIndex((singleControl: F) => singleControl === nextNode.data));
      } else {
        mappedTreeNodes = this.treeNodesEl;
      }
    }
    return mappedTreeNodes;
  }

  /**
   * Return an array which contains the list of parent nodes
   * of the node passed into the function
   * The first element of the array holds the immediate parent
   * The last element of array holds the parent at the topmost level
   *
   * @param {F} treeNode
   * @returns {{ dataNodes: F[], toggledNode: F }}
   * @memberof MultilevelTreeTableComponent
   */
  getSubsequentParentNodes(treeNode: F): { dataNodes: F[], toggledNode: F } {
    // let treeControlDataNodes: F[] = this.treeControl.dataNodes.filter((singleNode: F) => singleNode['expandable']);
    let treeControlDataNodes: F[] = this.treeControl.dataNodes.filter((singleNode: F) => this.bIsExpandable(singleNode));

    // if node is at the top level
    // if (treeNode['level'] < 1) {
    if (this.nGetLevel(treeNode) < 1) {
      return { dataNodes: [], toggledNode: treeNode };
    } else {
      let startIndex: number = 0;
      if (this.bIsExpandable(treeNode)) {
        startIndex = treeControlDataNodes.findIndex((singleNode: F) => [treeNode].includes(singleNode));
      } else {
        let parentNodes: F[] = treeControlDataNodes.filter((singleNode: F) => this.treeControl.getDescendants(singleNode).includes(treeNode));
        return { dataNodes: parentNodes.reverse(), toggledNode: treeNode };
      }
      treeControlDataNodes.splice(startIndex);
      treeControlDataNodes = treeControlDataNodes
        .filter((singleNode: F) => this.nGetLevel(singleNode) < this.nGetLevel(treeNode));
      // .filter((singleNode: F) => singleNode['level'] < treeNode['level']);
      let previousParentIndex: number = treeControlDataNodes.reverse()
        .findIndex((singleNode: F) => this.nGetLevel(singleNode) === 0);
      // .findIndex((singleNode: F) => singleNode['level'] === 0);
      treeControlDataNodes = treeControlDataNodes.slice(0, previousParentIndex + 1);
      return { dataNodes: treeControlDataNodes, toggledNode: treeNode };
    }
  }

  /**
   * Returns an array of children affected by the toggle
   * of the node passed into the function
   *
   * @param {MatTreeNode<F>} matTreeNode
   * @returns {F[]}
   * @memberof MultilevelTreeTableComponent
   */
  getAffectedChildrenNodes(matTreeNode: MatTreeNode<F>): F[] {
    return this.treeControl.getDescendants(matTreeNode.data);
  }

  /**
   * Extracts HTML Elements out of a MatTreeNode<F>
   *
   * @param {MatTreeNode<F>} inputNode
   * @returns {ITreeNodeStructure}
   * @memberof MultilevelTreeTableComponent
   */
  populateTreeNodeStructure(inputNode: MatTreeNode<F>): ITreeNodeStructure {
    let treeNodeStructure: ITreeNodeStructure = {
      nodeEl: inputNode['_elementRef'].nativeElement,
      lineHolder: { containerEl: null },
      treeTableCell: {
        treeTableCellEl: null,
        expand: { buttonHolderEl: null },
      }
    };
    treeNodeStructure.lineHolder.containerEl = treeNodeStructure.nodeEl.querySelectorAll('div.connect-line-holder')[0] as HTMLDivElement;

    // node is not expandable
    treeNodeStructure.lineHolder.verticalLineEl = ((!!treeNodeStructure.lineHolder.containerEl)) ? treeNodeStructure.lineHolder.containerEl.querySelectorAll('div.connect-line-vertical')[0] as HTMLDivElement : null;
    treeNodeStructure.treeTableCell.treeTableCellEl = treeNodeStructure.nodeEl.querySelectorAll('div.tree-table-cell-content')[0] as HTMLDivElement;
    treeNodeStructure.treeTableCell.expand.buttonHolderEl = treeNodeStructure.nodeEl.querySelectorAll('div.expand-button-holder')[0] as HTMLDivElement;
    treeNodeStructure.treeTableCell.expand.buttonEl = (!!treeNodeStructure.treeTableCell.expand.buttonHolderEl) ? treeNodeStructure.treeTableCell.expand.buttonHolderEl.querySelectorAll('button')[0] as HTMLButtonElement : null;
    return treeNodeStructure;
  }

  /**
   * Position the div.connect-horizontal-line
   *
   * @param {MatTreeNode<F>} parentNode
   * @param {MatTreeNode<F>[]} immediateChildrenNodes
   * @memberof MultilevelTreeTableComponent
   */
  renderHorizontalLines(parentNode: MatTreeNode<F>, immediateChildrenNodes: MatTreeNode<F>[]) {
    let adjust: IAdjust = { top: 0, left: 0, bottom: 0, right: 0, width: 0, height: 0 };
    let parentDOMNode: ITreeNodeStructure = this.populateTreeNodeStructure(parentNode);
    let immediateChildrenDOMNodes: ITreeNodeStructure[] = [];
    immediateChildrenNodes.forEach((singleChild: MatTreeNode<F>) => { immediateChildrenDOMNodes.push(this.populateTreeNodeStructure(singleChild)) });
    let horizontalLineEl: HTMLDivElement = this.renderer.createElement('div');
    this.renderer.setAttribute(horizontalLineEl, 'class', 'connect-line-horizontal');
    let existingChildren = parentDOMNode.lineHolder.verticalLineEl.querySelectorAll('div.connect-line-horizontal');

    // remove any existing div.connect-horizontal-line
    if (!!existingChildren.length) {
      existingChildren.forEach((singleLine: HTMLDivElement) => { this.renderer.removeChild(parentDOMNode.lineHolder.verticalLineEl, singleLine); });
    } else { }
    immediateChildrenDOMNodes.forEach((singleNode: ITreeNodeStructure) => {
      adjust.top = singleNode.treeTableCell.treeTableCellEl.offsetTop - singleNode.treeTableCell.treeTableCellEl.offsetHeight / 2 - parentDOMNode.treeTableCell.treeTableCellEl.offsetTop;
      adjust.left = 0;
      this.renderer.setAttribute(horizontalLineEl,
        'style',
        'top: ' + adjust.top.toFixed(2) + 'px;' +
        'left: ' + adjust.left.toFixed(2) + 'px;');
      this.renderer.appendChild(parentDOMNode.lineHolder.verticalLineEl, horizontalLineEl.cloneNode(true))
    });
  }

  /**
   * Position the div.connect-vertical-line
   *
   * @param {MatTreeNode<F>} affectedNode
   * @param {MatTreeNode<F>} lastChild
   * @memberof MultilevelTreeTableComponent
   */
  renderVerticalLines(affectedNode: MatTreeNode<F>, lastChild: MatTreeNode<F>) {
    let adjust: IAdjust = { top: 0, left: 0, bottom: 0, right: 0, width: 0, height: 0 };
    let affectedDOMNode: ITreeNodeStructure = this.populateTreeNodeStructure(affectedNode);
    let lastDOMChild: ITreeNodeStructure = this.populateTreeNodeStructure(lastChild);
    adjust.top = affectedDOMNode.treeTableCell.treeTableCellEl.offsetHeight / 2;
    adjust.left = affectedDOMNode.treeTableCell.expand.buttonHolderEl.offsetWidth / 2;
    adjust.height = lastDOMChild.treeTableCell.treeTableCellEl.offsetTop - lastDOMChild.treeTableCell.treeTableCellEl.offsetHeight / 2 - affectedDOMNode.treeTableCell.treeTableCellEl.offsetTop;
    this.renderer.setAttribute(
      affectedDOMNode.lineHolder.verticalLineEl,
      'style',
      'top: ' + adjust.top.toFixed(2) + 'px; ' +
      'left: ' + adjust.left.toFixed(2) + 'px; ' +
      'height: ' + adjust.height.toFixed(2) + 'px;'
    );
  }

  /**
   * Trigger renderVerticalLines(param, param) and/or 
   * renderHorizontalLines(param, param) by passing 
   * appropriate parameters
   *
   * @param {F} treeNode
   * @memberof MultilevelTreeTableComponent
   */
  prepareForRender(treeNode: F) {
    let matTreeNode: MatTreeNode<F>
    matTreeNode = this.mapToTreeNode([treeNode])[0];
    if (matTreeNode.data['expandable']) {
      let subsequentParents: { dataNodes: F[], toggledNode: F } = { dataNodes: [], toggledNode: treeNode };
      subsequentParents = this.getSubsequentParentNodes(treeNode);
      let subsequentParentsMapped: MatTreeNode<F>[] = [];
      subsequentParentsMapped = this.mapToTreeNode(subsequentParents.dataNodes, subsequentParents.toggledNode);
      let affectedChildren: F[] = [];
      affectedChildren = this.getAffectedChildrenNodes(matTreeNode);
      let affectedChildrenMapped = this.mapToTreeNode(affectedChildren);

      // reference node is not at the top level when 
      // an expand/collapse operation is performed
      if (!!subsequentParentsMapped.length) {
        subsequentParentsMapped.forEach((singleParentNode: MatTreeNode<F>) => {
          let immediateChildren: MatTreeNode<F>[] = this.mapToTreeNode(this.getAffectedChildrenNodes(singleParentNode))
            .filter((singleChildNode: MatTreeNode<F>) => singleChildNode.level === (singleParentNode.level + 1));
          if (!!immediateChildren.length) {
            this.renderHorizontalLines(singleParentNode, immediateChildren);
            let lastAffectedChild = immediateChildren.reduce((lastChild: MatTreeNode<F>, singleChild: MatTreeNode<F>) => {
              if (singleChild.level === singleParentNode.level + 1)
                lastChild = singleChild;
              return lastChild;
            }, null);
            this.renderVerticalLines(singleParentNode, lastAffectedChild);
          }
        });
      } else { }

      // reference node is expanded
      if (!!affectedChildrenMapped.length) {

        if (matTreeNode.isExpanded) {
          let lastChild: MatTreeNode<F> = affectedChildrenMapped.reduce((lastChild: MatTreeNode<F>, singleChild: MatTreeNode<F>) => {
            if (singleChild.level === matTreeNode.level + 1)
              lastChild = singleChild;
            return lastChild;
          }, null);
          this.renderVerticalLines(matTreeNode, lastChild);
          let immediateChildren: MatTreeNode<F>[] = affectedChildrenMapped.filter((singleChild: MatTreeNode<F>) => singleChild.level === treeNode['level'] + 1);
          this.renderHorizontalLines(matTreeNode, immediateChildren);

          affectedChildrenMapped.forEach((singleChild: MatTreeNode<F>) => {
            if (singleChild.data['expandable']) {
              let nextLevelChildren: MatTreeNode<F>[] = this.mapToTreeNode(this.getAffectedChildrenNodes(singleChild)).filter((singleNestedChild: MatTreeNode<F>) => singleNestedChild.level === (singleChild.level + 1));
              if (singleChild.isExpanded) {
                let nextLevelLastChild: MatTreeNode<F> = nextLevelChildren.reduce((lastChild: MatTreeNode<F>, singleNestedChild: MatTreeNode<F>) => {
                  if (singleNestedChild.level === singleChild.level + 1)
                    lastChild = singleNestedChild;
                  return lastChild;
                }, null);
                this.renderVerticalLines(singleChild, nextLevelLastChild);
                this.renderHorizontalLines(singleChild, nextLevelChildren);
              } else { }
            } else { }
          });

        } else { }
      } else { }
    } else { }
  }

  /**
   * Function to trigger rendering of initiate lines
   *
   * @memberof MultilevelTreeTableComponent
   */
  connectLines(activeNode?: F) {
    if (!!activeNode) {
      this.prepareForRender(activeNode);
    } else if (this.treeNodesEl && (this.treeNodesEl.length > 0)) {
      this.treeNodesEl.forEach((singleNode: MatTreeNode<F>) => {
        this.prepareForRender(singleNode.data)
      })
    }
  }

  checkboxChange(singleColumn: ISimplifiedColumnConfig, treeNode: F, eventData: MatCheckboxChange) {
    let hierarchyTree = this.treeControl.dataNodes;
    this.propertyChange.emit({
      hierarchyTree: hierarchyTree, // = this.treeControl.dataNodes
      singleColumn: singleColumn,
      treeNode: treeNode,
      eventData: eventData
    });
    this.dataChange$.next(this.treeData);
  }

  //footer button
  buttonClick(singleColumn: any, singleContent: any) {
    this.tableAction.emit({
      singleColumn: singleColumn,
      singleContent: singleContent
    });
    this.dataChange$.next(this.treeData);
  }

  /**
   * Check if all child nodes are selected
   *
   * @param {F} treeNode
   * @returns {boolean}
   * @memberof MultilevelTreeTableComponent
   */
  bAllChildrenSelected(treeNode: F): boolean {
    return this.treeControl.getDescendants(treeNode).every((singleNode: F) => this.checklistSelection.isSelected(singleNode));
  }

  /**
   * Check if some child nodes are selected
   *
   * @param {F} treeNode
   * @returns {boolean}
   * @memberof MultilevelTreeTableComponent
   */
  bSomeChildrenSelected(treeNode: F): boolean {
    let result = this.treeControl.getDescendants(treeNode).some((singleNode: F) => this.checklistSelection.isSelected(singleNode));
    return result && !this.bAllChildrenSelected(treeNode);
  }

  /**
   * Child node is selected
   *
   * @param {F} treeNode
   * @param {MatCheckboxChange} eventData
   * @memberof MultilevelTreeTableComponent
   */
  childSelectionChange(treeNode: F, eventData: MatCheckboxChange): void {
    this.checklistSelection.toggle(treeNode);
    this.parentSelectionCheck(treeNode);
  }

  /**
   * Parent node is selected
   *
   * @param {F} treeNode
   * @param {MatCheckboxChange} eventData
   * @memberof MultilevelTreeTableComponent
   */
  parentSelectionChange(treeNode: F, eventData: MatCheckboxChange) {
    this.checklistSelection.toggle(treeNode);
    const descendants: F[] = this.treeControl.getDescendants(treeNode);
    this.checklistSelection.isSelected(treeNode) ? this.checklistSelection.select.apply(this.checklistSelection, descendants) : this.checklistSelection.deselect.apply(this.checklistSelection, descendants);
    descendants.every((singleNode: F) => this.checklistSelection.isSelected(singleNode));
    this.parentSelectionCheck(treeNode);
  }

  /**
   * Check all the parents when a child node is selected
   *
   * @param {F} treeNode
   * @memberof MultilevelTreeTableComponent
   */
  parentSelectionCheck(treeNode: F): void {
    this.getSubsequentParentNodes(treeNode).dataNodes.forEach((parentNode: F) => {
      const nodeSelected: boolean = this.checklistSelection.isSelected(parentNode);
      const bChildSelectionFlag: boolean = this.bAllChildrenSelected(parentNode);
      if (nodeSelected && !bChildSelectionFlag) {
        this.checklistSelection.deselect(parentNode);
      } else if (!nodeSelected && bChildSelectionFlag) {
        this.checklistSelection.select(parentNode);
      }
    })
  }

  toggleSelection(treeNode: F, eventData: MatCheckboxChange): void {
    this.checklistSelection.toggle(treeNode);
  }

  selectSystem(eventData: Event, treeNode: F) {
    this.treeControl.dataNodes.forEach((singleNode: F) => { singleNode['bIsSelected'] = false; })
    treeNode['bIsSelected'] = !treeNode['bIsSelected'];
  }

  doNothing(): void { }
}

