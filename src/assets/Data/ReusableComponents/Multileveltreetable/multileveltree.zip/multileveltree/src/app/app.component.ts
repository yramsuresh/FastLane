import { Component, OnInit } from '@angular/core';
import { AppService } from './app.service';
import { ITreeTableConfig } from './multilevel-tree-table/multilevel-tree-table.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'multileveltree';
  treeTableConfig: ITreeTableConfig;
  treeData: any;

  constructor(private appService: AppService) {
  }

  ngOnInit() {
    this.treeDataConfiguration();
  }

  treeDataConfiguration() {
    this.appService.getTreeData().subscribe(data => this.treeData = data);
    this.treeTableConfig = {
      childKey: 'contentsList',
      bIsTreeCollapsed: 'allNodesCollapse',
      rowSelections: {
        // bIsNodeClickable: true,
        selectionType: 'multiple',
        bIsParentNodeSelectable: true
      },
      columnConfig: [
        {
          header: {
            bIsFixed: true,
            contents: [ {
              type: 'text',
              label: 'Description'
            }]
          },
          content: {
            type: 'text',
            property: 'displayText'
          },
          footer: {
          },
          bIsTreeContent: true,
          style: {
            width: '180px'
          }
        },
        {
          header: {
            bIsFixed: true,
            contents: [ {
              type: 'text',
              label: 'Total Size'
            }]
          },
          content: {
            type: 'text',
            property: 'totalSize'
          },
          footer: {
           
          },
          style: {
            width: '180px'
          }
        }
      ]
    };
  }
}
