import React, { Component } from 'react';

class NavBar extends Component {
    render() { 
        return (
          <div>
            <nav className="navbar navbar-light bg-info">
                <h3>Personal Detail Form</h3>
            </nav>
          </div>
        );
    }
}
 
export default NavBar;