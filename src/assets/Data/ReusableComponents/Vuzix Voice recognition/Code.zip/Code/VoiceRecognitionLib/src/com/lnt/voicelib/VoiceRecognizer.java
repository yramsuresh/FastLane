package com.lnt.voicelib;

import java.util.ArrayList;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

public class VoiceRecognizer {

	private static SpeechRecognizer m_objSpeechRecognizer = null;
	private static VoiceRecognizer m_objVoiceRecognizer = null;
	private static Intent m_objRecognizerIntent = null;
	
	protected VoiceRecognizer(){
		//empty to avoid initialization
	}

	/**get recognizer instance**/
	public static VoiceRecognizer getVoiceRecognizerInstance(){
		if(null == m_objVoiceRecognizer){
			m_objVoiceRecognizer = new VoiceRecognizer();
		}

		return m_objVoiceRecognizer;
	}

	/**initialize speech recognition**/
	public void initSpeechRecognition(String p_strRecognitionEngineType, Context p_objContext, RecognitionListener p_objRecognitionListener){

		if(p_strRecognitionEngineType.equalsIgnoreCase("Google") && SpeechRecognizer.isRecognitionAvailable(p_objContext)){

			m_objSpeechRecognizer = SpeechRecognizer.createSpeechRecognizer(p_objContext);
			m_objSpeechRecognizer.setRecognitionListener(p_objRecognitionListener);
			m_objRecognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
			m_objRecognizerIntent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
			m_objRecognizerIntent.putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, p_objContext.getPackageName());
			m_objSpeechRecognizer.startListening(m_objRecognizerIntent);
			//m_objSpeechIntent.putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 10000);			
			//m_objRecognizerIntent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 6);

		}else{
			//for vuzix speech recognition
			
		}
	}

	/**get error message**/
	public static String getErrorText(int errorCode) {
		String message;
		switch (errorCode) {
		case SpeechRecognizer.ERROR_AUDIO:
			message = "Audio recording error";
			break;
		case SpeechRecognizer.ERROR_CLIENT:
			message = "Client side error";
			break;
		case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:
			message = "Insufficient permissions";
			break;
		case SpeechRecognizer.ERROR_NETWORK:
			message = "Network error";
			break;
		case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:
			message = "Network timeout";
			break;
		case SpeechRecognizer.ERROR_NO_MATCH:
			message = "No match";
			break;
		case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:
			message = "RecognitionService busy";
			break;
		case SpeechRecognizer.ERROR_SERVER:
			message = "error from server";
			break;
		case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:
			message = "No speech input";
			break;
		default:
			message = "Didn't understand, please try again.";
			break;
		}
		return message;
	}

	/**destroy speech recognition service **/
	public static void stopSpeechRecognition(){
		if(m_objSpeechRecognizer!=null) {
			m_objSpeechRecognizer.stopListening();
			m_objSpeechRecognizer.cancel();
			m_objSpeechRecognizer.destroy();
		}
		m_objSpeechRecognizer = null;
	}

	/**get speech results **/
	public static String getSpeechResults(Bundle results){
		ArrayList<String> matches = results
				.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
		String text = "";
		for (String result : matches)
			text += result + "\n";
		return text;
	}

}
