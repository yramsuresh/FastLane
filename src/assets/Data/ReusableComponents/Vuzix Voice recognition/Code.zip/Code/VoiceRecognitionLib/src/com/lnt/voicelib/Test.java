package com.lnt.voicelib;

import android.app.Activity;
import android.os.Bundle;
import android.speech.RecognitionListener;

public class Test extends Activity implements RecognitionListener {

	@Override
	protected void onCreate(Bundle b){
		super.onCreate(b);
		VoiceRecognizer objRecognizer = VoiceRecognizer.getVoiceRecognizerInstance();
		objRecognizer.initSpeechRecognition("google",Test.this, this);
	}

	@Override
	public void onBeginningOfSpeech() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onBufferReceived(byte[] buffer) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEndOfSpeech() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onError(int error) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onEvent(int eventType, Bundle params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onPartialResults(Bundle partialResults) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onReadyForSpeech(Bundle params) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onResults(Bundle results) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void onRmsChanged(float rmsdB) {
		// TODO Auto-generated method stub
		
	}

}
