import React from 'react';
import Home from './example/Home';

function App() {
  return (
    <div>
      <Home />
    </div>
  );
}

export default App;
