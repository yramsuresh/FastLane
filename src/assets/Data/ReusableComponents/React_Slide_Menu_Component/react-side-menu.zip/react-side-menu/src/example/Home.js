import React from 'react';

import Sidebar from '../components/Sidebar';
import Panel from '../example/Panel';
import Content from '../example/Content';

const styles = {
  contentHeaderMenuLink: {
    textDecoration: 'none',
    color: 'black',
    padding: 8,
  },
  content: {
    padding: '10px',
  },
};

class Home extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      docked: false,
      open: false,
      transitions: true,
      touch: true,
      shadow: true,
      pullRight: false,
      touchHandleWidth: 20,
      dragToggleDistance: 30,
    };

    this.renderPropCheckbox = this.renderPropCheckbox.bind(this);
    this.renderPropNumber = this.renderPropNumber.bind(this);
    this.onSetOpen = this.onSetOpen.bind(this);
    this.menuButtonClick = this.menuButtonClick.bind(this);
  }

  onSetOpen(open) {
    this.setState({ open });
  }

  menuButtonClick(ev) {
    ev.preventDefault();
    this.onSetOpen(!this.state.open);
  }

  renderPropCheckbox(prop) {
    const toggleMethod = (ev) => {
      const newState = {};
      newState[prop] = ev.target.checked;
      this.setState(newState);
    };

    return (
      <p key={prop}>
        <label htmlFor={prop}>
          <input
            type='checkbox'
            onChange={toggleMethod}
            checked={this.state[prop]}
            id={prop}
          />
          {prop}
        </label>
      </p>
    );
  }

  renderPropNumber(prop) {
    const setMethod = (ev) => {
      const newState = {};
      newState[prop] = parseInt(ev.target.value, 10);
      this.setState(newState);
    };

    return (
      <p key={prop}>
        {prop}{' '}
        <input type='number' onChange={setMethod} value={this.state[prop]} />
      </p>
    );
  }

  render() {
    const sidebar = <Content />;

    const contentHeader = (
      <span>
        {!this.state.docked && (
          // eslint-disable-next-line
          <a
            onClick={this.menuButtonClick}
            href='#'
            style={styles.contentHeaderMenuLink}
          >
            =
          </a>
        )}
        <span> Sidebar Example</span>
      </span>
    );

    const sidebarProps = {
      sidebar,
      docked: this.state.docked,
      sidebarClassName: 'custom-sidebar-class',
      contentId: 'custom-sidebar-content-id',
      open: this.state.open,
      touch: this.state.touch,
      shadow: this.state.shadow,
      pullRight: this.state.pullRight,
      touchHandleWidth: this.state.touchHandleWidth,
      dragToggleDistance: this.state.dragToggleDistance,
      transitions: this.state.transitions,
      onSetOpen: this.onSetOpen,
    };

    return (
      <Sidebar {...sidebarProps}>
        <Panel title={contentHeader}>
          <div style={styles.content}>
            <p>
              <b>Current rendered sidebar properties:</b>
            </p>
            {['open', 'docked', 'shadow', 'pullRight'].map(
              this.renderPropCheckbox
            )}
          </div>
        </Panel>
      </Sidebar>
    );
  }
}

export default Home;
