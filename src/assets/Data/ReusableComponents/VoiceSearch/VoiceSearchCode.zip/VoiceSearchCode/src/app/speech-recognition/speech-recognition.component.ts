import { Component, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-speech-recognition',
  templateUrl: './speech-recognition.component.html',
  styleUrls: ['./speech-recognition.component.css']
})
export class SpeechRecognitionComponent implements OnInit {
  speechToText: string;
  @Output() searchTextEmitter: EventEmitter<string> = new EventEmitter<string>();
  @Output() resetData: EventEmitter<string> = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
    //console.log('Inside speech-recognition resetUserData()');

    if ('webkitSpeechRecognition' in window) {
      // speech recognition API supported
      console.log("supported")
    } else {
      console.log("not supported")
      
      // speech recognition API not supported
    }
  }

  voiceSearch(): void {
    //console.log('Inside speech-recognition voiceSearch()');
    this.resetData.emit();
    (<HTMLInputElement>document.getElementById('textToSearch')).value = '';
    (<HTMLImageElement>document.getElementById('image')).src = 'assets/mic-animate.gif';
    
    const {webkitSpeechRecognition} = (window as any)
    const recognition = new webkitSpeechRecognition();
    recognition.lang = 'en-UK';
    
    recognition.onresult = (event) => {
      this.speechToText = event.results[0][0].transcript;
      (<HTMLInputElement>document.getElementById('textToSearch')).value = this.speechToText;

      if(this.speechToText){
        this.emitSearchValue();
      }
    }

    recognition.start();

    recognition.onspeechend = function() {
      recognition.stop();
    }

    recognition.onaudioend = function() {
      (<HTMLImageElement>document.getElementById('image')).src = 'assets/mic.gif';
    }
  }

  emitSearchValue() : any {
    //console.log('Inside speech-recognition emitSearchValue()');
    this.searchTextEmitter.emit(this.speechToText);
  }

}
