import { Component, OnInit, NgZone } from '@angular/core';

@Component({
  selector: 'app-search-data',
  templateUrl: './search-data.component.html',
  styleUrls: ['./search-data.component.css']
})
export class SearchDataComponent implements OnInit {userData = [
 {
 firstName: 'John',
 lastName: 'Doe',
 address: '7687 Park Port'
 },
 {
 firstName: 'Alice',
 lastName: 'Smith',
address: '156 Avenue Ports'
 },
{
firstName: 'Peter',
 lastName: 'Jones',
 address: '5203 Northern Centre'
 },
 {
 firstName: 'Bob',
 lastName: 'Brown',
 address: '91057 Rider Club'
 },
 {
 firstName: 'Tom',
 lastName: 'Smith',
 address: '16288 West Harbour'
}
 ];


  filteredData: any;

  constructor(private _ngZone: NgZone) { }

  ngOnInit(): void {
    //console.log('Inside search-data ngonInit()');
    this.filteredData = this.userData;
  }

  returnText(value: string) {
    //console.log('Inside search-data returnText()');
    //use ngZone to detect changes in the view template
    this._ngZone.run(() => {
      this.updateData(value);
    })
  }

  updateData(text: string) {
    //console.log('Inside search-data updateData()');
    if(text){
      // search for the given string in all properties of all data objects in the array
      this.filteredData = this.userData.filter(obj =>  
        Object.values(obj).some(val => 
          val.toString().toLowerCase().includes(text.toLowerCase())
        )
      );
    }
  }

  resetUserData() {
    //console.log('Inside search-data resetUserData()');
    this.filteredData = this.userData;
  }
}
