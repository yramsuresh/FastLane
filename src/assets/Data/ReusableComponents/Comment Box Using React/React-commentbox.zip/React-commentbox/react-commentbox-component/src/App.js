import React from "react";
import CommentBox from "./Component/Commentbox/comment";
import ReactDOM from "react-dom";
import "./Component/Commentbox/css/bootstrap.css";
import "./Component/Commentbox/css/commentbox.css";
function App() {
  return (
    <div className="App">
 
      <CommentBox />
    
     

    </div>
  );
}

export default CommentBox;

