import React from "react";

const AccordianItem = props => {
  const {
    Header,
    itemData,
    onclickHeader,
    indexVal,
    toggleState,
    length
  } = props;
  let itemDescClass = "content expand ";
  let itemHeaderClass = "title expand ";
  //itemDescClass += indexVal !== length - 1 ? " bottomBorder" : "";
  if (toggleState || indexVal == 0) {
    itemHeaderClass += " is-expanded";
    itemDescClass += " is-expanded showactive";
    
  }
  return (
    <div>
      <div
        className={itemHeaderClass}
        data-indexval={indexVal}
        data-togglestate={toggleState}
        onClick={onclickHeader}>
         {Header}
      </div>
      <div
        className={itemDescClass}
        style={{ display: toggleState ? "block" : "none" }}>
        {itemData}
      </div>
    </div>
  );
};
export default AccordianItem;
