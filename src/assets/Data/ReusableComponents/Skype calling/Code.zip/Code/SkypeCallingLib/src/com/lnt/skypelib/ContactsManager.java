package com.lnt.skypelib;

import java.util.ArrayList;

import android.content.ContentProviderOperation;
import android.content.ContentResolver;
import android.content.Context;
import android.net.Uri;
import android.provider.ContactsContract;
import android.provider.ContactsContract.CommonDataKinds;

public class ContactsManager {
	
	private static String MIMETYPE = "vnd.android.cursor.item/com.skype.android.skypecall.action";
	private static String ACCOUNT_TYPE = "com.skype.contacts.sync";
	private static String ACCOUNT_NAME = "skype";

	public static int addContact(Context context,String username,String skypename){
		ContentResolver resolver = context.getContentResolver();
		ArrayList<ContentProviderOperation> ops = 
				new ArrayList<ContentProviderOperation>();

		ops.add(ContentProviderOperation
				.newInsert(addCallerIsSyncAdapterParameter(
						ContactsContract.RawContacts.CONTENT_URI, true))
				.withValue(ContactsContract.RawContacts.ACCOUNT_NAME, 
						ACCOUNT_NAME)
				.withValue(ContactsContract.RawContacts.ACCOUNT_TYPE, 
						ACCOUNT_TYPE)
				.withValue(ContactsContract.RawContacts.AGGREGATION_MODE, 
						ContactsContract.RawContacts.AGGREGATION_MODE_DEFAULT)
				.build());
		ops.add(ContentProviderOperation
				.newInsert(addCallerIsSyncAdapterParameter(
						ContactsContract.Data.CONTENT_URI, true))
				.withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
				.withValue(ContactsContract.Data.MIMETYPE, 
						ContactsContract.CommonDataKinds.StructuredName.CONTENT_ITEM_TYPE)
				.withValue(CommonDataKinds.StructuredName.DISPLAY_NAME, 
						username.trim())
				.build());

		ops.add(ContentProviderOperation
				.newInsert(addCallerIsSyncAdapterParameter(
						ContactsContract.Data.CONTENT_URI, true))
				.withValueBackReference(ContactsContract.Data.RAW_CONTACT_ID, 0)
				.withValue(ContactsContract.Data.MIMETYPE, MIMETYPE)
				.withValue(ContactsContract.Data.DATA1, skypename.trim())
				.build());


		try {
			resolver.applyBatch(ContactsContract.AUTHORITY, ops);
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		return 1;
	}

	private static Uri addCallerIsSyncAdapterParameter(Uri uri, 
			boolean isSyncOperation) {
		if (isSyncOperation) {
			return uri.buildUpon()
					.appendQueryParameter(ContactsContract.CALLER_IS_SYNCADAPTER,
							"true").build();
		}
		return uri;
	}
}