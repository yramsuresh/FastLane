package com.lnt.skypelib;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract.Data;

public class SkypeCall {

	public static final int SKYPE_CALL_REQUEST_CODE = 1;
	public static SkypeCall m_objSkypeCall = null;

	protected SkypeCall(){
		//prevent initialization
	}

	public static SkypeCall getSkypeCallInstance(){
		if(null == m_objSkypeCall){
			m_objSkypeCall = new SkypeCall();
		}	
		return m_objSkypeCall;
	}

	/**add skype contact**/
	public static void addSkypeContact(Context p_objContext, String p_strSkypeAccountUserName, String p_strSkypeName){
		if(!SkypeUtils.isStringEmpty(p_strSkypeAccountUserName) && !SkypeUtils.isStringEmpty(p_strSkypeName) ){
			try{
				ContactsManager.addContact(p_objContext,p_strSkypeAccountUserName,p_strSkypeName);
			}catch(Exception ex){
				ex.printStackTrace();
			}
		}
	}

	/**get skype contact list **/
	public static List<HashMap<String,String>> getSkypeContactList(Context p_objContext){

		List<HashMap<String,String>> objContactsList = new ArrayList<HashMap<String,String>>();

		try{

			Cursor c = p_objContext.getContentResolver().query(
					Data.CONTENT_URI,
					new String[] {Data.DISPLAY_NAME,Data.DATA1},
					Data.MIMETYPE+"= ?", 
					new String[] { "vnd.android.cursor.item/com.skype.android.skypecall.action" },
					null);


			while (c != null && c.moveToNext()) {
				String display_name = c.getString(0);
				String skype = c.getString(1);
				HashMap<String,String> objMapContact = new HashMap<String, String>();
				objMapContact.put(display_name, skype);
				objContactsList.add(objMapContact);
			}


		}catch(Exception ex){
			ex.printStackTrace();
		}

		return objContactsList;

	}

	/**fetch skype name from list **/
	public static String fetchSkypeNameFromList(Context p_objContext, int p_iContactId){

		String strSkypeName = null;

		try{
			List<String> objContactList = new ArrayList<String>();
			List<HashMap<String,String>> objContactsList = getSkypeContactList(p_objContext);
			String strDisplayName = objContactList.get(p_iContactId).substring(3);
			for(int i=0 ; i <objContactsList.size(); i++){
				if(objContactsList.get(i).containsKey(strDisplayName)){
					strSkypeName = objContactsList.get(i).get(strDisplayName);
					break;
				}
			}
		}catch(Exception ex){
			ex.printStackTrace();
		}

		return strSkypeName;
	}

	/** make skype call**/
	public static void makeSkypeCall(Context p_objContext, String skype_name){
		try{
			Intent skype_intent = new Intent("android.intent.action.VIEW");
			skype_intent.setClassName("com.skype.raider", "com.skype.raider.Main");
			skype_intent.setData(Uri.parse("skype:" +skype_name+ "?call"));
			skype_intent.putExtra("SKYPE_NAME",skype_name);  	
			((Activity)p_objContext).startActivityForResult(skype_intent, SKYPE_CALL_REQUEST_CODE);
		}catch(Exception ex){
			ex.printStackTrace();
		}
	}

}
