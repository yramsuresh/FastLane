package com.lnt.skypelib;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class SyncService extends Service {

	private static final Object sSyncAdapterLock = new Object();
	private static SyncAdapter mSyncAdapter = null;

	@Override
	public void onCreate() {
		//Log.I("Sync Service created.");
		synchronized (sSyncAdapterLock){
			if(mSyncAdapter == null){
				mSyncAdapter = new SyncAdapter(getApplicationContext(),true);
			}
		}
	}

	@Override
	public IBinder onBind(Intent intent) {
		//Log.I("Sync Service binded.");
		return mSyncAdapter.getSyncAdapterBinder();
	}
}
