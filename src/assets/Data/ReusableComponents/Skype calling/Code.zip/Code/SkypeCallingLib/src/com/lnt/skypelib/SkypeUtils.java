package com.lnt.skypelib;

public class SkypeUtils {

	public static boolean isStringEmpty(String p_strInput){
		if(p_strInput!= null && p_strInput.length() != 0 ){
			return false;
		}else{
			return true;
		}
	}
}
