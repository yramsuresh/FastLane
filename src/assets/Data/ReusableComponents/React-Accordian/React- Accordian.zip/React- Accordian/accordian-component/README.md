Content
1. Accordian with Component State
2. Accordian with Redux

Steps to follow:
1. Clone the repository
2. npm install
3. npm start



