import React from "react";
import AccordianReact from './Component/Accordian'
import "./Component/Accordian/accordian.css";
function App() {
  let data = [
    {
      header: "First Panel",
      item: "First Panel Description goes here"
    },
    {
      header: "Second Panel",
      item: "Second First Panel Description goes here"
    },
    {
      header: "Third Panel",
      item: "Third First Panel Description goes here"
    },
    {
      header: "Fourth Panel",
      item: "Fourth First Panel Description goes here"
    }
  ];
  return (
    <div className="App">
    <div className="accordiancontainer">
        <h1>React Accordian Panel</h1>
      <div class="accordionreact">
      <AccordianReact
        item={data}
     
      />
      </div>
      </div>
    </div>
  );
}

export default App;
