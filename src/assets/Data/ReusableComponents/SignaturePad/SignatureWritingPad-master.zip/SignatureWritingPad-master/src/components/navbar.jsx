import React, { Component } from 'react';
import "../App.css"

class NavBar extends Component {
    render() { 
        return (
          <div>
            <nav className="navbar navbar-light bg-info">
                <h2>Signature Writing Pad</h2>
            </nav>
          </div>
        );
    }

}
 
export default NavBar;