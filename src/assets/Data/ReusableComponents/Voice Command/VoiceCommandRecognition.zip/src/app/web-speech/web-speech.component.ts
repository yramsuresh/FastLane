import { ChangeDetectorRef, Component, OnInit, ViewChild } from '@angular/core';
import { SpeechRecognizerService } from './shared/services/speech-recognizer.service';

import { SpeechNotification } from './shared/model/speech-notification';
import { SpeechError } from './shared/model/speech-error';
// import { ActionContext } from './shared/model/strategy/action-context';
import { Router } from '@angular/router';
import { CdkDragStart, CdkDropList, moveItemInArray } from '@angular/cdk/drag-drop';
import {MatSort, MatTableDataSource} from '@angular/material';

@Component({
  selector: 'wsa-web-speech',
  templateUrl: './web-speech.component.html',
  styleUrls: ['./web-speech.component.css']
})
export class WebSpeechComponent implements OnInit {

  title = 'Material Table column drag and drop';

  public data = [
    {Id: 1, First_Name: 'Pratik', Last_Name: 'Patil', Weight: 70,Height:5.8,Gender:'Male',Status:'Married',Job:'Service',Education:'MBA',Location:'Thane'},
    {Id: 2, First_Name: 'Pavitra', Last_Name: 'Farde', Weight: 55,Height:5.7,Gender:'Female',Status:'Married',Job:'Service',Education:'MCA',Location:'Airoli'},
    {Id: 3, First_Name: 'Nikita', Last_Name: 'Churi', Weight: 50,Height:5.9,Gender:'Female',Status:'Married',Job:'Service',Education:'PHD',Location:'Vashi'},
    {Id: 4, First_Name: 'Vipul', Last_Name: 'Singh', Weight: 72,Height:5.4,Gender:'Male',Status:'UnMarried',Job:'Service',Education:'MD',Location:'Thane'},
    {Id: 5, First_Name: 'Taruja', Last_Name: 'Sharma', Weight: 60,Height:5.2,Gender:'Female',Status:'Married',Job:'Service',Education:'MBA',Location:'Powai'},
    {Id: 6, First_Name: 'Nitish', Last_Name: 'Mehata', Weight: 75,Height:5.5,Gender:'Male',Status:'Married',Job:'Business',Education:'MS',Location:'Pune'},
    {Id: 7, First_Name: 'Kirti', Last_Name: 'Borade', Weight: 78,Height:5.6,Gender:'Female',Status:'UnMarried',Job:'Service',Education:'MCA',Location:'Nashik'},
    {Id: 8, First_Name: 'Mithilesh', Last_Name:'Pandey', Weight: 75,Height:5.2,Gender:'Male',Status:'Married',Job:'Service',Education:'MD',Location:'Thane'},
    {Id: 9, First_Name: 'Anannya', Last_Name: 'Gupta', Weight: 64,Height:5.4,Gender:'Female',Status:'Married',Job:'Business',Education:'MCA',Location:'Airoli'},
    {Id: 10, First_Name: 'Prathamesh', Last_Name:'Kale', Weight: 72,Height:5.3,Gender:'Male',Status:'UnMarried',Job:'Service',Education:'PHD',Location:'Pune'},
  ];

  checkboxValues=['Id','First_Name', 'Last_Name','Weight','Height','Gender','Status','Job','Education','Location']
  columnsToDisplay;
  searchText;
  displayedColumns: string[] = [];
  private sort: MatSort;

  previousIndex: number;

  finalTranscript = '';
  recognizing = false;
  notification: string;

  constructor(private changeDetector: ChangeDetectorRef,
              private speechRecognizer: SpeechRecognizerService,private router: Router) { }

  ngOnInit() {
    this.initRecognition();
    this.notification = null;
  }

  startButton(event) {
    if (this.recognizing) {
      this.speechRecognizer.stop();
      this.finalTranscript = '';
      return;
    } 

    this.speechRecognizer.start(event.timeStamp);
  }

  private initRecognition() {
    this.speechRecognizer.onStart()
      .subscribe(data => {
        this.recognizing = true;
        this.notification = 'I\'m listening...';
        this.detectChanges();
      });

    this.speechRecognizer.onEnd()
      .subscribe(data => {
        this.recognizing = false;
        this.detectChanges();
        this.notification = null;
        this.finalTranscript = '';
      });

    this.speechRecognizer.onResult()
      .subscribe((data: SpeechNotification) => {
        const message = data.content.trim();
        if (data.info === 'final_transcript' && message.length > 0) {
          this.finalTranscript = `${this.finalTranscript}${message}`;          
          this.detectChanges();
        } 
      });

    this.speechRecognizer.onError()
      .subscribe(data => {
        switch (data.error) {
          case SpeechError.BLOCKED:
          case SpeechError.NOT_ALLOWED:
            this.notification = `Cannot run the demo.
            Your browser is not authorized to access your microphone. Verify that your browser has access to your microphone and try again.
            `;
            break;
          case SpeechError.NO_SPEECH:
            this.notification = `No speech has been detected. Please try again.`;
            break;
          case SpeechError.NO_MICROPHONE:
            this.notification = `Microphone is not available. Plese verify the connection of your microphone and try again.`;
            break;
          default:
            this.notification = null;
            break;
        }
        this.recognizing = false;
        this.detectChanges();
      });
  }

  detectChanges() {
    this.changeDetector.detectChanges();
  }
}
