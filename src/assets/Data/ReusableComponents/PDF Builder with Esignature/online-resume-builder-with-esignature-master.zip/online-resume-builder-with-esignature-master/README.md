# Online Resume Builder

Client side pdf generation using angular 8 and pdfmake.
Export to pdf in Angular 8 and pdfmake

You can generate your resume in pdf format at client side. We do not store any information at server side. it is a pure client side resume builder application. 

## Features

- Personal Details with Social Media hyperlink
- Profile picture
- Multiple Experiences and Educational details in table format
- Other details
- QR code
- PDF Open, Print and Download option

## Developed and Maintained By

This project is developed by [NgDevelop](https://www.ngdevelop.tech/) for the [Export to pdf in Angular 8 using pdfmake](https://www.ngdevelop.tech/angular-8-export-to-pdf-using-pdfmake/) blog.
