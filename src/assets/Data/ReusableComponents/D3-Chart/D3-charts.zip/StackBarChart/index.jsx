import React, { Component } from "react";
import * as d3 from "d3";
import data from "./data";
import './index.css';

class StackBarChartComponent extends Component {
    componentDidMount() {
        this.drowChart();
    }

    drowChart() {
        /* This is main function of your stack bar chart
            all the stack bar chart logic has written over here
            You can make changes as per your requirements.
            In this expain me are using X-label as date you can make changes as your array
        */
        console.log('this.porps', this.props);
        if (this.props.dataSet && this.props.dataSet.length > 0) {
            console.log('Data present');
            const group = this.props.groupList;
            var parseDate = d3.timeFormat("%b-%Y");
            var mainDivName = "charts";
            this.props.dataSet.forEach(function (d) {
                d = type(d);
            });
            var layers = d3.stack()
                .keys(group)
                .offset(d3.stackOffsetDiverging)
                (this.props.dataSet);
            var svg = d3.select("svg"),
                margin = {
                    top: 20,
                    right: 30,
                    bottom: 60,
                    left: 60
                },
                width = +svg.attr("width"),
                height = +svg.attr("height");

            var x = d3.scaleBand()
                .rangeRound([margin.left, width - margin.right])
                .padding(0.1);

            x.domain(this.props.dataSet.map(function (d) {
                return d.date;
            }))

            var y = d3.scaleLinear()
                .rangeRound([height - margin.bottom, margin.top]);

            y.domain([d3.min(layers, stackMin), d3.max(layers, stackMax)])

            function stackMin(layers) {
                return d3.min(layers, function (d) {
                    return d[0];
                });
            }

            function stackMax(layers) {
                return d3.max(layers, function (d) {
                    return d[1];
                });
            }

            var z = d3.scaleOrdinal(d3.schemeCategory10);

            var maing = svg.append("g")
                .selectAll("g")
                .data(layers);
            var g = maing.enter().append("g")
                .attr("fill", function (d) {
                    return z(d.key);
                });

            var rect = g.selectAll("rect")
                .data(function (d) {
                    d.forEach(function (d1) {
                        console.log('d', d, d1);
                        d1.key = d.key;
                        return d1;
                    });
                    return d;
                })
                .enter().append("rect")
                .attr("data", function (d) {
                    var data = {};
                    data["key"] = d.key;
                    data["value"] = d.data[d.key];
                    var total = 0;
                    group.map(function (d1) {
                        total = total + d.data[d1];
                        return total;
                    });
                    data["total"] = total;
                    return JSON.stringify(data);
                })
                .attr("width", x.bandwidth)
                .attr("x", function (d) {
                    return x(d.data.date);
                })
                .attr("y", function (d) {
                    return y(d[1]);
                })
                .attr("height", function (d) {
                    return y(d[0]) - y(d[1]);
                });

            rect.on("mouseover", function () { 
                d3.select(this).transition()
                    .duration('50')
                    .attr('opacity', '.85');
                tooltip.transition()
                    .duration(50)
                    .style("opacity", 1);
                let num = (Math.round((d.value / d.data.all) * 100)).toString() + '%';
                tooltip.html(num)
                    .style("left", (d3.event.pageX + 10) + "px")
                    .style("top", (d3.event.pageY - 15) + "px");
            })
            rect.on("mouseout", function () { tooltip.style("display", "none"); })
            rect.on("mousemove", function (d) {
                var xPosition = d3.mouse(this)[0] - 15;
                var yPosition = d3.mouse(this)[1] - 25;
                tooltip.attr("transform", "translate(" + xPosition + "," + yPosition + ")");
                tooltip.select("text").text();
            });

            // Prep the tooltip bits, initial display is hidden
            var tooltip = svg.append("g")
                .attr("class", "tooltip")
                .style("display", "none");

            tooltip.append("rect")
                .attr("width", 30)
                .attr("height", 20)
                .attr("fill", "white")
                .style("opacity", 0.5);

            tooltip.append("text")
                .attr("x", 15)
                .attr("dy", "1.2em")
                .style("text-anchor", "middle")
                .attr("font-size", "12px")
                .attr("font-weight", "bold");

            svg.append("g")
                .attr("transform", "translate(0," + y(0) + ")")
                .call(d3.axisBottom(x))
                .append("text")
                .attr("x", width / 2)
                .attr("y", margin.bottom * 0.5)
                .attr("dx", "0.32em")
                .attr("fill", "#000")
                .attr("font-weight", "bold")
                .attr("text-anchor", "start")
                .text("Month");

            svg.append("g")
                .attr("transform", "translate(" + margin.left + ",0)")
                .call(d3.axisLeft(y))
                .append("text")
                .attr("transform", "rotate(-90)")
                .attr("x", 0 - (height / 2))
                .attr("y", 15 - (margin.left))
                .attr("dy", "0.32em")
                .attr("fill", "#000")
                .attr("font-weight", "bold")
                .attr("text-anchor", "middle")
                .text("Sales");


            function type(d) {
                d.date = parseDate(new Date(d.date));
                group.forEach(function (c) {
                    d[c] = +d[c];
                });
                return d;
            }

            var helpers = {
                getDimensions: function (id) {
                    var el = document.getElementById(id);
                    var w = 0,
                        h = 0;
                    if (el) {
                        var dimensions = el.getBBox();
                        w = dimensions.width;
                        h = dimensions.height;
                    } else {
                        console.log("error: getDimensions() " + id + " not found.");
                    }
                    return {
                        w: w,
                        h: h
                    };
                }
            };

        }
        else {
            console.log('Please send dataset as props');
        }
    }

    render() {
        return (
            <React.Fragment>
                <div id="charts">
                    <svg width="800" height="500"></svg>
                </div>
            </React.Fragment>
        );
    }
}

export default class StackBarChart extends Component {
    render() {
        const groupList = ["Laptops", "Processor", "Ram"];
        return (
            <div>
                graph plot here
                <StackBarChartComponent
                    groupList={groupList} // This is for grouping the stack bar chart
                    dataSet={data} // provide your data set here 
                />
            </div>
        );
    }
}
