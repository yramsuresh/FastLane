import React, { Component } from "react";
import data from "./data";
import rd3 from "react-d3-library";
const BarChart = rd3.BarChart;

export default class BarChartComponent extends Component {
  constructor() {
    super();
    this.state = {
      d3: '',
    }
  }

  componentDidMount() {
    this.setState({ d3: data });
  }
  render() {
    return <BarChart data={this.state.d3} />;
  }
}
