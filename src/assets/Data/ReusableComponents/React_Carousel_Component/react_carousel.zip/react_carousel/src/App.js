import React, {Component} from 'react';
import Carousel from  './components/Carousel'
import './App.scss';

class App extends Component {
  state= {
    images: [
      './assets/images/download.jpg', 
      './assets/images/download1.jpg',
      './assets/images/download2.jpg',
      './assets/images/download3.jpg',
      './assets/images/download4.jpg',
      './assets/images/download5.jpg'
    ],
    activeComponent: 0,
    autoplay: false,
    playbackSpeed: 2000
  }
  changeAutoplayHandler = ()=> {
    let locPlay = this.state.autoplay
    this.setState({autoplay: !locPlay})
  }
  nextImgHandler= ()=>{
    let x = this.state.images.length-1
    if(this.state.activeComponent===x){
      this.setState({activeComponent: 0})
    }
    else {
      this.setState((prevState, props)=> {
        return {
          activeComponent: prevState.activeComponent + 1
        }
      })
    }
  }
  prevImgHandler= ()=>{
    let x = this.state.images.length-1
    if(this.state.activeComponent === 0){
      this.setState({activeComponent: x})
    }
    else {
      this.setState((prevState, props)=> {
        return {
          activeComponent: prevState.activeComponent - 1
        }
      })
    }
  }
  render(){
    return (
      <div className="container-fluid">
        <h1 className="text-center title-text">Image Carousel</h1>
        <Carousel images={this.state.images} 
          autoplay={this.state.autoplay} 
          playbackSpeed={this.state.playbackSpeed}
          activeComponent={this.state.activeComponent}
          changePlay= {this.changeAutoplayHandler} 
          prev={this.prevImgHandler} 
          next={this.nextImgHandler}/>
      </div>
    )
  }
}

export default App;
