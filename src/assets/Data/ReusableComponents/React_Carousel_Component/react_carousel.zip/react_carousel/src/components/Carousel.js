import React, {Fragment} from 'react'
import {Form} from 'react-bootstrap'

const Carousel = props => {
    if(props.autoplay){
        setTimeout(() => {
            return props.next()
        }, props.playbackSpeed);
    }
    return (
        <Fragment>
            <div className="row">   
                <div className="carousel-container col-8 mx-auto">
                    <div className="carousel-image">
                        <img src={props.images[props.activeComponent]} alt="carousel"/>
                        {
                            props.autoplay ? null: <>
                             <div className="carousel-contorls cntrl-prev" onClick={props.prev}>
                                <span className="icon">
                                    <i className="fa fa-angle-left" aria-hidden="true"></i>    
                                </span> 
                            </div>
                            <div className="carousel-contorls cntrl-next" onClick={props.next}>
                                <span className="icon">
                                    <i className="fa fa-angle-right" aria-hidden="true"></i>    
                                </span>
                            </div>
                            </>
                        }
                       
                    </div>
                    <p className="text-center text-italic">
                       {props.activeComponent+1}/{props.images.length}
                    </p>
                    <Form.Group controlId="formBasicCheckbox">
                        <Form.Check type="checkbox" label="Auto Play" checked={props.autoplay} onChange={props.changePlay} />
                    </Form.Group>
                </div>
           </div>
        </Fragment>
    )
    
}

export default Carousel