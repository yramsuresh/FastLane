import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  
  dataSourceITSpendPerUser: any;
  public lineChartData: any;
  donutChartData:any;
  barChartData:any;
  
  constructor() { }
  
  
  ngOnInit(){
    let rObj={};
    rObj["label"] = "linechart";
    rObj["value"] = 200;
    this.lineChartData = [
      {label: "Current Year Company Revenue", value: "17659.679"},
      {label: "Company Revenue Prior Year 1 (Mean)", value: "19249.051"},
      {label: "Company Revenue Prior Year 2 (Mean)", value: "21366.446"}
    ]
    this.donutChartData = [
      {label: "Current Year Company Revenue", value: "17659.679"},
      {label: "Company Revenue Prior Year 1 (Mean)", value: "19249.051"},
      {label: "Company Revenue Prior Year 2 (Mean)", value: "21366.446"}
    ]
    this.barChartData = {
      "P1": {"key":"workplace_services_p1","value":"0.33"},
      "P2": {"key":"workplace_services_p1","value":"0.45"},
      "P3": {"key":"workplace_services_p1","value":"0.24"}
    }
    
    //For Line chart
    this.dataSourceITSpendPerUser = {
      chart: {
        animation: false,
        smartLineAlpha: "100",
        showlegend: "1",
        labelFont: "OpenSansRegular",
        labelFontSize: 16,
        legendItemFontSize: 16,
        showToolTip: false,
        legendposition: "bottom",
        usedataplotcolorforlabels: "0",
        showTooltip: "1",
        theme: "fint",
        lineThickness: "3",
        formatNumberScale: 0,
        anchorBgColor: "#03abba",
        showHoverEffect: 0, // disable zoom on mouse over
        interactiveLegend: 0, // disable hide of line
        divLineDashed: 0, // change chart background dot line to stright line
        legendItemFontColor: "#75787b",
        palettecolors: "#03abba",
        numberprefix:  "$"
      },
      categories: [{
        category: [{
          label: "2016"
        },
        {
          label: "2017"
        },
        {
          label: "2018"
        }
      ]
    }],
    dataset: [{
      seriesname: "Company Revenue",
      "data": this.lineChartData
    }]
    
  };
  
}




}




