import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AppComponent } from './app.component';
import { PieChartComponent } from './pie-chart/pie-chart.component';
import { BarchartComponent } from './barchart/barchart.component';
import { LineChartComponent } from './line-chart/line-chart.component';
import { HomeComponent } from './home/home.component';
import { DrillDownDonutChartComponent } from './drill-down-donut-chart/drill-down-donut-chart.component';
import { GeneratePDFComponent } from './generate-pdf/generate-pdf.component'


const appRoutes: Routes = [
  {
    path: '',
    component:HomeComponent
  },
  {
    path: 'PieChartComponent',
    component:PieChartComponent
  },
  {
    path: 'app-barchart',
    component:BarchartComponent
  },
  {
    path: 'line-chart',
    component:LineChartComponent
  },
  {
    path: 'drill-down-donut-chart',
    component:DrillDownDonutChartComponent
  },
  {
    path: 'app-generate-pdf',
    component:GeneratePDFComponent
  }

]

@NgModule({
  declarations: [
    AppComponent,
    PieChartComponent,
    BarchartComponent,
    LineChartComponent,
    HomeComponent,
    DrillDownDonutChartComponent,
    GeneratePDFComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(
      appRoutes,
      {useHash: true}
    )
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
