import { Component, OnInit } from '@angular/core';

import * as jspdf from 'jspdf';
declare var jsPDF: any;
import 'jspdf-autotable';
declare var $: any;

@Component({
  selector: 'app-generate-pdf',
  templateUrl: './generate-pdf.component.html',
  styleUrls: ['./generate-pdf.component.css']
})
export class GeneratePDFComponent implements OnInit {

 
  objPersonnelCostAllocation = [20, 30];
  objHardwareCostAllocation = [10, 20];
  objSoftwareCostAllocation = [10, 20];
  objOutsourcingCostAllocation = [30, 40];

  constructor() { }

  ngOnInit() {
    
  }

  generatePDF() {
		let pdf = new jsPDF('p', 'pt', 'a4');
		var number = 3;
	
		var header = function(data) {
			pdf.setFontSize(16);
			pdf.setTextColor(40);
		};
		
		for (var i = 1; i < number; i++) {
			var headertable = 'Table_header' + i;
			var Datatable = 'Table_Data' + i;
			
			var res1 = document.getElementById(headertable);
			var Table_header1 = pdf.autoTableHtmlToJson(res1);
			var elem1 = document.getElementById(Datatable);
			var Table_Data1 = pdf.autoTableHtmlToJson(elem1);
		
			
			pdf.autoTable(Table_header1.columns, Table_header1.data, {
				startY: pdf.autoTableEndPosY() + 10,
				pageBreak: 'auto',
				beforePageContent: header,
			
				headerStyles: {
					fillColor: [ 255, 255, 255 ],
					textColor: 40
				},
				styles: {
					fontSize: 14,
					tableWidth: 280,
					columnWidth: '50',
          valign: 'left',
          halign: 'center',
          rowHeight: 50
        },
        margin: {
					horizontal: 10,
					top: 10,
					bottom: 10
				}
				
			});
			
			
			pdf.autoTable(Table_Data1.columns, Table_Data1.data, {
				startY: pdf.autoTableEndPosY() + 0,
				pageBreak: 'auto',
				theme: 'grid',
				beforePageContent: header,
				headerStyles: {
					fillColor: [ 255, 255, 255 ],
					textColor: 20
				},
				styles: {
					overflow: 'linebreak',
					fontSize: 12,
					tableWidth: 280,
					columnWidth: 'wrap',
					valign: 'middle',
					halign: 'center',
					rowHeight: 30
				},
				alternateRowStyles: {},
				bodyStyles: {},
				columnStyle: {
					columnWidth: 'auto'
				},
				columnStyles: {
					0: { columnWidth: 80 },
					1: { columnWidth: 80 },
					2: { columnWidth: 80 },
					3: { columnWidth: 80 }
				},
				margin: {
					horizontal: 10,
					top: 10,
					bottom: 10
				}
			});
			
		}
		
		pdf.setFont('OpenSansReg');
		pdf.setFontType('italic');
		pdf.save('CompanyDetails.pdf');
  }
  
	triggerCollapse(obj) {
		if ($(obj).data('lastState') === undefined ||  $(obj).data('lastState') === 1){
			$('.panel-collapse')
			.removeData('bs.collapse')
			.collapse({
				parent: 'false',
				toggle: 'false'
			})
			.collapse('show')
			.removeData('bs.collapse')
			.collapse({
				parent: '#accordion',
				toggle: 'false'
			});
			$('.panel-title').find('a:first').attr('aria-expanded', true);
			
			$(obj).data('lastState', 0);
			
		}else{
			$('.collapse.in').collapse('hide');
			$(obj).data('lastState', 1);
		}
  }
  
}
